# P6 — Setup Tournament: Gesamtplan

> Entscheidungen (Stand Planung):
> - **Match-Regeln:** Vorrunde-Regelsatz + KO-Regelsatz getrennt (sonst global). Optional kleiner Zusatz: „Final/Halbfinale ohne Tiebreak"-Toggle, da in fast allen Mails vorhanden und billig.
> - **Liga:** feste Kategorien A/B/C als Multi-Select.
> - **Scope:** Consolation-Bracket + Mighty-Finisher-Quali + ELO + Push/Timer/Vibration ALLE Teil von P6.
> - **Vorgehen:** Erst dieser Gesamtplan, Review, dann Umsetzung phasenweise.
> - **Phase 6:** bleibt Teil von P6, wird aber als letzter Block nach Phasen 0–5 umgesetzt.
> - **Aktueller Schritt:** Phase 0 (Datenmodell) wird umgesetzt.

## Ausgangslage (was schon existiert)

- 7-Schritt-Wizard, Riverpod + Drift + Supabase, Domain-Logik in `packages/kubb_domain/`.
- Formate `roundRobin / singleElimination / schoch / swiss / …ThenKo`.
- **Schoch/Swiss-Pairing existiert** (`pairing/swiss_system.dart`, Buchholz + Rematch-Vermeidung), RPC `tournament_pair_round`. Schoch-Durchgänge konfigurierbar (`_swissRounds`).
- Pool-Phase (`PoolPhaseConfig`: groupCount, snake/random/seeded), KO-Phase (`KoPhaseConfig`: qualifierCount, manual/auto seeding, 3.-Platz).
- Anmeldung + **Warteliste** (`tournament_participants.registration_status = waitlist`), `registration_closes_at`.
- Live-Dashboard, Bracket-, Pool-Standings-, Score-Consensus-Screens.

### Lücken, die NICHT existieren (Neubau)
- **Pitch-Zuteilung**: Spalte `tournament_matches.pitch_number` existiert, wird aber NIE befüllt. Im Trainingsmatch gibt es KEINE Pitch-Logik (nur Deko-Widget `kubb_stack_preview`). → komplett neu.
- **ELO / Auto-Ranking**: ELO ist hart auf `1200` verdrahtet. → neu.
- **Push / Match-Timer / Vibration**: keine Push-Infra, kein Timer-UI. → neu (heaviest).
- **Meta-Felder** (Ort, Datum, PDFs, Gebühr, Kontakt, Infotexte, Regel-Varianten): fehlen alle.
- **Match-Regeln pro Phase** (Vorrunde ≠ KO): aktuell nur ein globaler Regelsatz.
- **Consolation-Bracket** + **Mighty-Finisher als Quali**: fehlen.

---

## Phase 0 — Datenmodell & Migrationen (Fundament)

> **Status: erledigt & verifiziert** (Branch `feat/p6-tournament-setup`).
> - ✅ Migration `supabase/migrations/20261001000001_tournament_setup_fields.sql` — additive Spalten (Meta, Liga A/B/C, Gebühr/Zahlarten, PDFs, `rule_variants`, `ko_match_format`, `pitch_plan`, `mighty_finisher_quali`, `consolation_bracket`). `match_format` bleibt = Vorrunden-Format.
> - ✅ Domain `packages/kubb_domain/lib/src/tournament/tournament_setup.dart` — `LeagueCategory`, `MatchFormatSpec`, `RuleVariants`, `PitchPlan`/`PitchMode`/`PitchSortStrategy`, `MightyFinisherQuali`, `ConsolationConfig` (alle mit JSON-Round-Trip). `dart analyze` clean, 16 Tests grün.
> - ✅ `TournamentConfigDraft` additiv erweitert (alle neuen Header-Felder). Analyze clean, 19 Bestands-Tests grün.
> - ⏳ **Bewusst verschoben:** `tournament_create`-RPC-Wiring → Phase 1 (wo die Felder befüllt werden); Storage-Buckets für PDFs → Phase 1; `player_ratings` (ELO) → Phase 5; `tournament_shootouts` → Phase 6 (YAGNI — keine Tabellen ohne Konsumenten).

Alle nachfolgenden Phasen hängen hieran. Sauber zuerst.

### `tournaments` Spalten-Erweiterung
- **Meta:** `location`, `venue_address`, `event_starts_at` (timestamptz), `checkin_until` (Vor-Ort-Anmeldung), `weather_note`.
- **Liga:** `league_categories text[]` (Werte aus `A|B|C`).
- **Gebühr:** `entry_fee_cents int`, `currency text default 'CHF'`, `payment_methods text[]` (`cash|twint|card`).
- **Kontakt:** `contact_name`, `contact_phone`.
- **Infotexte:** `info_food text`, `info_travel text`, `info_accommodation text`.
- **Dateien (Supabase Storage):** `rules_pdf_url`, `site_map_pdf_url`.
- **Regel-Varianten** `rule_variants jsonb`: `{ sureshot: bool, diggy: bool, opening_rule: '2-4-6', strafkubb: {...}, scoring: 'ekc'|'classic' }`.
- **Match-Regeln getrennt:**
  - `prelim_match_format jsonb` = `{ sets_to_win, max_sets, time_limit_seconds, tiebreak_enabled, tiebreak_after_seconds, break_between_matches_seconds }`
  - `ko_match_format jsonb` = gleiche Struktur + `final_no_tiebreak bool`
- **Pitch-Plan** `pitch_plan jsonb`: `{ mode: 'range'|'manual', range_from, range_to, numbers: int[], order: int[], group_assignment: { 'A': [int], ... }, sort_strategy: 'top_seeds_low_numbers'|'manual' }`.
- **Quali/Consolation:**
  - `mighty_finisher_quali jsonb` = `{ enabled, slots, source: 'group_runner_ups' }`
  - `consolation_bracket jsonb` = `{ enabled, source_rounds: [...], match_format: {...} }`

### Neue Tabellen
- `player_ratings` — `(user_id, discipline: 'solo'|'team', elo int default 1200, games int, updated_at)`. Gruppen-ELO = Summe der Mitglieder.
- `tournament_shootouts` — Mighty-Finisher-Ergebnisse: `(tournament_id, match_or_quali_ref, participant_id, sticks_used int, sudden_death_round int, result)`.
- ggf. `tournament_pitches` falls JSON zu eng wird (vorerst JSON).

### Storage
- Buckets `tournament-rules`, `tournament-maps` (PDF), RLS: Schreiben nur Organizer, Lesen öffentlich/Teilnehmer.

### Domain (`kubb_domain`)
- `MatchFormatSpec` (sets/time/tiebreak), getrennt prelim/ko.
- `RuleVariants`, `LeagueCategory` enum, `PitchPlan`, `ConsolationConfig`, `MightyFinisherConfig`.
- `TournamentConfigDraft` + `validate()` erweitern.
- RPC `tournament_create` Signatur erweitern + Audit-Event.

---

## Phase 1 — Setup Screen 1 (Stammdaten/Meta)

> Aufgeteilt in **1a (Backbone)** und **1b (UI + PDF-Upload)**.
>
> **Phase 1a: erledigt & verifiziert.**
> - ✅ Migration `20261001000002_tournament_create_setup.sql` — `tournament_create` um `p_setup jsonb DEFAULT '{}'` erweitert (drop+recreate+grant), persistiert alle P6-Header-Felder; `scoring` jetzt aus `p_setup` (ekc/classic) statt hartkodiert.
> - ✅ `TournamentConfigDraft.toSetupConfig()` (snake_case-Wire-Map).
> - ✅ Port `TournamentRemote.createTournament` um optionales `setup`-Argument erweitert; Repository + zentraler Fake + lokaler Wizard-Test-Fake angepasst; Actions-Provider übergibt `draft.toSetupConfig()`.
> - ✅ Verifiziert: `dart analyze` clean, 157 Tournament-Tests + Outbox/Sync-E2E grün, neue `toSetupConfig`-Tests.
>
> **Phase 1b-i: erledigt & verifiziert.** Stammdaten-Step ausgebaut (`tournament_setup_wizard.dart`): Name (jetzt mit `Key('wizardNameField')`) · Liga A/B/C Multi-Select-Chips · Ort · Datum+Startzeit (Picker) · Anmeldeschluss (Picker) · Wertung EKC/klassisch. Controller-Setter + ARB-Keys (de, einsprachig) + `gen-l10n`. Design-System-konform (KubbTokens, Touch-Targets ≥48dp). `dart analyze` clean, 158 Tournament-Tests grün (neuer End-to-End-Test: Liga/Wertung → Setup-Payload).
>
> **Phase 1b-ii: erledigt & verifiziert.** Restliche Meta-Felder im Stammdaten-Step (Adresse · Gebühr+Zahlarten Bar/Twint/Karte · Kontakt Name+Tel · Infotexte Verpflegung/Anfahrt/Übernachtung/Wetter · Regel-Varianten-Toggles Sureshot/Diggy/Strafkubb). **Voller PDF-Upload**: `file_selector`-Dependency (file_picker scheiterte an win32-Konflikt mit package_info_plus), Storage-Bucket+RLS-Migration `20261001000003_tournament_storage.sql`, `SupabaseTournamentPdfUploader` (+ Provider, mockbar). Overflow-Fix in `_FieldLabel`. `dart analyze` clean, 160 Tournament-Tests grün. **Committet `be53ed2` + gepusht** auf `origin/feat/p6-tournament-setup` (gesamter Stand inkl. P5/P7-WIP, auf User-Wunsch).

Felder: Name · Liga (Multi A/B/C) · Ort + Adresse · Datum/Uhrzeit · App-Anmeldeschluss · Vor-Ort-Check-in-Zeit · Gebühr + Zahlarten · Kontakt (Name/Tel) · **Regel-PDF Upload** · **Lageplan-PDF Upload** · Infotexte (Verpflegung/Anfahrt/Übernachtung/Wetter) · Regel-Varianten-Toggles (Sureshot/Diggy/2-4-6/Strafkubb) · Scoring EKC vs classic.
- Keyboard-Overflow-sicher (siehe P7).
- PDF-Upload → Storage (Buckets+RLS neu, keine Storage-Infra im Repo vorhanden), Fortschritt + Fehlerzustand.

## Phase 2 — Setup Screen 2 (Vorrunde + Pitches)

> **Slice 2-a: erledigt & verifiziert.** Teamgröße als **Min./Max. Spieler pro Team** (1–6; min=max = feste Grösse, 1 = Einzel) im Teilnehmer-Step + **Pitch-Plan-UI** im Vorrunde-Step (Modus Range/manuell, Von/Bis bzw. Nummernliste, Sortierung Beste-auf-tiefste/manuell, Pitch-Anzahl-Vorschau). Controller `setTeamSize`/`setMaxTeamSize`/`setPitchPlan`. Neue Spalte `max_team_size` (in Migration 20261001000001 ergänzt, `team_size` = Minimum), Create-RPC persistiert sie aus `p_setup`.
> **Slice 2-b: erledigt & verifiziert.** Vorrunden-Match-Regeln im Vorrunde-Step: **Zeit pro Match** · **Tiebreak an/aus** + **Tiebreak nach (Min.)** · **Pause zwischen Matches**. 2 neue Draft-Felder (`prelimTiebreakAfterSeconds` nullbar = ohne Tiebreak, `breakBetweenMatchesSeconds`); `toMatchFormatConfig` trägt `tiebreak_enabled`/`tiebreak_after_seconds`/`break_between_matches_seconds`; Validierung Tiebreak-Zeit ≤ Zeitlimit. `dart analyze` clean, **163 Tournament-Tests grün**.
> **Offen in Phase 2:** Gruppen→Pitch-Zuteilung für Pool-Formate — **zurückgestellt**, bis Pool-/Hybrid-Formate im Wizard freigeschaltet sind (aktuell nur roundRobin + swiss aktiv). Damit ist der Phase-2-Kern (Vorrunde-Regeln + Pitches + Teamgröße) abgeschlossen.


- **Vorrunde-Typ:** Gruppenphase vs Schoch.
- **Vorrunde-Regelsatz** (gemeinsam): Sätze, Tiebreak an/aus + Tiebreak-Zeit, Zeitlimit, Pause zwischen Matches.
- **Teamgröße** 1–6 (= min Gruppengröße bei Anmeldung), **Max-Teilnehmer**.
- **Pitch-Konfiguration:** Modus *Range* (von–bis) ODER *manuelle Nummernliste* + manuelle Sortierung (reorderable list).
- **Bei Gruppenphase:** Anzahl Gruppen · Pitch-Zuteilung pro Gruppe · Pitch-Sortierung (höchstgerankte auf welche Pitches).
- **Bei Schoch:** Anzahl Durchgänge (existiert) · Hinweis max 8 Punkte/Satz.

## Phase 3 — Setup Screen 3 (Bracket / KO)

- Single-Out vs **Double-KO**.
- KO-Stufe: 1/64 · 1/32 · 1/16 · 1/8 · 1/4 (= `qualifierCount`).
- **KO-Regelsatz** (Tiebreak an/aus, Zeitlimit) + `final_no_tiebreak`.
- **Begegnungslogik:** Beste vs Schlechteste / 1.-vs-2.-Platz (seeding/pairing-Strategie).
- **Tiebreak-Methode:** klassischer Tiebreak vs **Mighty-Finisher-Shootout** (umschaltbar).
- **Mighty-Finisher-Quali** an/aus + Slots (Stufe zwischen Vorrunde und KO).
- **Consolation-Bracket** an/aus + Quelle (welche KO-Verlierer) + eigener Regelsatz.

## Phase 4 — Anmeldung

- Auf „aktuelle Turniere"-Kacheln: Button **Details** + Button **An-/Abmelden**.
- Solo (teamSize 1): direkte Anmeldung mit Spielername.
- Team: N Mitspieler (= teamSize) aus Teampool wählen, Validierung der Gruppengröße.
- Bei Anmeldung: **alle Teammitglieder bekommen Info** + sehen Status „angemeldet".
- Warteliste bei Ausbuchung; Anmeldeschluss-Enforcement.

## Phase 5 — Ranking / Seeding (zwischen Anmeldeschluss und Start)

- **Manuelles Ranking** durch Veranstalter (Seeding-UI existiert).
- **ELO-System:** `player_ratings`, Berechnung nach Match-Ende; Gruppen-ELO = Summe der Mitglieder.
- **Auto-Seeding** aus ELO, wenn genug Daten; sonst manuell.
- Vor Start: Platzanzahl-Prüfung, Veranstalter-Bestätigung.

## Phase 6 — Start & Live-Execution (größte/risikoreichste Phase)

- Live schalten → erste Runde berechnen (Pairing existiert) → **Pitch-Zuteilung** in Range/Liste → **BYE/Freilos-Auffüllung** auf die schlechtest-gerankten.
- **Push** „dein Platz ist da, leg los" an alle Teilnehmer (Push-Infra muss neu — überlappt Prompt 6 / Notification-Logik).
- **Match-Timer** auf Spielergeräten, Start bei Live-Schaltung, geräteübergreifend synchron.
- **Vibration** bei Zeitablauf; danach Resultat-Eingabe (Consensus existiert) bzw. in KO: Tiebreak/Mighty-Finisher-Rückmeldung an Veranstalter.
- **Runden-Progression:** nächste Runde erst publiziert, wenn ALLE Resultate der aktuellen Runde eingetragen sind.

## Phase 7 — Editierbarkeit & Bugfixes (aus P7-Prompt)

- Turnier editierbar bis Start.
- Keyboard-Overflow-Checks im gesamten Setup.

---

## Abhängigkeiten & Risiken
- **Phase 0 ist Voraussetzung für alles.**
- **Phase 6 (Push/Timer/Vibration)** ist die schwerste, eigenständige Baustelle (keinerlei Push-Infra vorhanden, geräteübergreifender Timer-Sync). Überlappt fachlich mit Prompt 6 (Notifications) → ggf. dort konsolidieren.
- ELO (Phase 5) ist Voraussetzung für Auto-Ranking; manuelles Ranking funktioniert ohne.
- Mighty-Finisher & Consolation: Config in Phase 3, Ausführung in Phase 6.
- Entscheidung „Vorrunde+KO getrennt" deckt NICHT „ab Halbfinale ohne Tiebreak" exakt ab → mit `final_no_tiebreak`-Toggle teilweise abgefangen.
