# Turnier-Setup-Wizard — Change-Spec (konsolidiert aus MilestoneTournaments.txt)

Quelle der Wünsche: `humanPlan/MilestoneTournaments.txt` (33 `#`-Kommentare).
Ist-Zustand abgeglichen mit:
- `lib/features/tournament/data/tournament_config_draft.dart`
- `lib/features/tournament/application/tournament_config_controller.dart`
- `lib/features/tournament/presentation/tournament_setup_wizard.dart`
- `.../widgets/_wizard_ko_config_step.dart`, `_wizard_pool_config_step.dart`, `swiss_config_section.dart`, `ko_model_explainer_sheet.dart`, `wizard_number_field.dart`
- `packages/kubb_domain/lib/src/tournament/tournament_setup.dart`

Kategorien: **WIZARD-UI** · **VALIDIERUNG/REQUIRED** · **NEUES-FELD/DEFAULT** · **CROSS-FEATURE** (wirkt ausserhalb des Wizards) · **OFFENE-ENTSCHEIDUNG** (braucht Entscheid).

Pfade relativ zu `KubbProj/`. Dateikürzel:
- `draft` = `lib/features/tournament/data/tournament_config_draft.dart`
- `ctrl` = `lib/features/tournament/application/tournament_config_controller.dart`
- `wizard` = `lib/features/tournament/presentation/tournament_setup_wizard.dart`
- `ko_step` = `.../widgets/_wizard_ko_config_step.dart`
- `pool_step` = `.../widgets/_wizard_pool_config_step.dart`
- `swiss` = `.../widgets/swiss_config_section.dart`
- `domain` = `packages/kubb_domain/lib/src/tournament/tournament_setup.dart`
- `l10n` = `lib/l10n/` (ARB-Dateien)

---

## Einträge K01–K33

### K01 — Jahreszahl an Turniername anhängen (Unique)
- **Zeile 58.** Original: *"Hier sollte immer noch eine Jahres Zahl angehängt werden, wenn ein Veranstalter dsa gleiche Tournier wieder erstellen will im nächsten jahr, … 2026 automatisch anhängen, damit der Tourniername auch Unique bleibt."*
- **Ziel:** Schritt 1 Stammdaten, Feld `displayName`.
- **Ist:** Reiner Freitext, min 3 / max 60 Zeichen; keine automatische Jahreszahl.
- **Soll:** Beim Speichern (oder beim Verlassen des Namensfeldes) automatisch ` <Jahr>` an den `displayName` anhängen, sofern noch keine 4-stellige Jahreszahl im Namen enthalten ist. Jahr = `eventStartsAt.year` falls gesetzt, sonst `DateTime.now().year`. Ergebnis dient als Eindeutigkeits-Hinweis (kein DB-Unique-Constraint hier). UI: Helper-Text "Jahr wird automatisch angehängt". maxLength ggf. um 5 erhöhen, damit der angehängte Suffix nicht abgeschnitten wird.
- **Kategorie:** NEUES-FELD/DEFAULT (+ kleine WIZARD-UI).
- **Dateien:** `draft` (`toSetupConfig`/`displayName`-Aufbereitung oder neue Helper), `wizard` (`_StepStammdaten`, Helper-Text), evtl. `ctrl.setDisplayName`.

### K02 — "Kein Verein" -> "Spasstournier – ohne Wertung" + keine Punktewertung
- **Zeile 69.** Original: *"hier sollte die Option 'Kein Verein (persönlich)' zu 'Spasstournier - ohne Wertung' umbenennt werden. Diese option hat zur folge, dass keine Punkte wertung gemacht wird. Merke dir das … für das entwickeln der Punktewertung/des Punktesystems im Tournierkontext."*
- **Ziel:** Schritt 1, `clubId`-Dropdown (`_ClubPickerField`), Wert "Kein Verein".
- **Ist:** Erster Dropdown-Eintrag `tournamentWizardClubNone` = "Kein Verein (persönlich)"; `clubId == null` => persönlich, nie liga-relevant; `league_categories` werden geleert.
- **Soll:** Label umbenennen in "Spasstournier – ohne Wertung". Semantik: `clubId == null` markiert das Turnier als wertungsfrei. Punktesystem (Liga/ELO/Scoring) MUSS später diesen Zustand respektieren (keine Punkte vergeben). Hinweis-Text anpassen.
- **Kategorie:** WIZARD-UI (Label) + CROSS-FEATURE (Punktesystem muss "ohne Wertung" auswerten).
- **Dateien:** `l10n` (`tournamentWizardClubNone`, `tournamentWizardClubHint`); CROSS-FEATURE: Punktesystem/Liga-Berechnung (noch nicht im Wizard-Scope).

### K03 — "Verein" darf nicht optional sein
- **Zeile 70.** Original: *"Das Darf auch nicht optional sein."* (unter [Verein/Host]).
- **Ziel:** Schritt 1, `clubId`.
- **Ist:** `clubId` optional; Default `null` (= Spasstournier).
- **Soll:** Die Auswahl muss aktiv getroffen werden — der User muss explizit entweder einen Verein ODER "Spasstournier – ohne Wertung" wählen. Kein impliziter Default; "optional"-Badge entfernen. Schritt 1 erst gültig, wenn eine bewusste Auswahl vorliegt. Umsetzung: Sentinel "noch nicht gewählt" vs. explizit "Spasstournier". Da das Dropdown nicht zwischen "null = Spasstournier" und "null = ungewählt" unterscheidet, braucht es einen zusätzlichen Wizard-State `clubChoiceMade` (bool) oder ein Enum.
- **Kategorie:** VALIDIERUNG/REQUIRED (+ kleine WIZARD-UI).
- **Dateien:** `wizard` (`_ClubPickerField`, `_stepValid` name-Step), evtl. `draft`/`ctrl` (Choice-State), `l10n`.

### K04 — Wertung beeinflusst Punkterfassung im MatchScreen
- **Zeile 125.** Original: *"Auf Basis dieser eingabe muss die Erfassung der Punkte im MatchScreen/SpielScreen beeinflusst werden."* (unter [Wertung/Scoring]).
- **Ziel:** Schritt 1, `scoring` ('ekc' | 'classic').
- **Ist:** `scoring` wird gespeichert; MatchScreen wertet es noch nicht aus.
- **Soll:** MatchScreen/SpielScreen muss je nach `scoring` die Punkteerfassung anpassen (EKC: 1 Pkt/Basiskubb + 3/Satz = 8 vs. classic).
- **Kategorie:** CROSS-FEATURE (Match-Screen / Punktesystem) — nicht reiner Wizard.
- **Dateien:** `lib/features/match/...` (Score-Erfassung), kein Wizard-Code.

### K05 — Diggy-Default auf AN
- **Zeile 137.** Original: *"Bei dem Diggy muss der default auch auf an sein."*
- **Ziel:** Schritt 1, Regeln, `ruleVariants.diggy`.
- **Ist:** `RuleVariants.diggy` Default `false` (`domain`).
- **Soll:** Default `true`. Im `RuleVariants`-Konstruktor (`domain`) `diggy = true`. (Achtung: `fromJson`-Fallback ebenfalls auf `true` setzen, sonst weichen alte Rows ab — Entscheid: Fallback bleibt für Round-Trip-Treue beim Default, neue Turniere starten mit `true`.)
- **Kategorie:** NEUES-FELD/DEFAULT.
- **Dateien:** `domain` (`RuleVariants`), ggf. `draft` Default-Konstruktor (nutzt `const RuleVariants()`).

### K06 — Anspielregel 2-4-6 ins UI abbilden
- **Zeile 138.** Original: *"Die Anspielregel 2- 4- 6 musst du auch abbilden."*
- **Ziel:** Schritt 1, Regeln, `ruleVariants.openingRule`.
- **Ist:** `openingRule` (Default '2-4-6') existiert im Datenmodell + Wire, hat aber KEIN UI im Wizard.
- **Soll:** UI-Element ergänzen (z.B. SegmentedButton/Radio oder Read-only-Anzeige der Regel "2-4-6"). Minimal: sichtbar machen; falls mehrere Werte gewünscht, Auswahl. Default bleibt '2-4-6'.
- **Kategorie:** NEUES-FELD/DEFAULT (+ WIZARD-UI).
- **Dateien:** `wizard` (`_StepStammdaten`, Regeln-Abschnitt), `l10n`.

### K07 — Eingabefelder 5 Zeilen
- **Zeile 169.** Original: *"Mache bei den eingabefeldern 5 Zeilen möglich."* (unter "Infos für Teilnehmer").
- **Ziel:** Schritt 1, Info-Freitextfelder (`infoFood`, `infoTravel`, `infoAccommodation`, `weatherNote`).
- **Ist:** `_PlainTextField(..., maxLines: 2)` für die vier Info-Felder.
- **Soll:** `maxLines: 5` (bzw. `minLines: 3, maxLines: 5`) für die Info-Felder.
- **Kategorie:** WIZARD-UI.
- **Dateien:** `wizard` (`_StepStammdaten`, die vier `_PlainTextField` mit `maxLines`).

### K08 — Single-Anmeldung: Spielername = Teamname (überall)
- **Zeilen 182 + 191.** Original (2×): *"Die Auswirkung muss dann auch auf die Anmeldung gehen, … wenn sich jemand bei Single Tournieren anmeldet als Singel ist sein Name in der App automatisch auch sein Teamname überall in den Matches etc."*
- **Ziel:** Schritt 2, `teamSize`/`maxTeamSize` (= 1 -> Singles). Wirkung auf Registrierung/Matches.
- **Ist:** `teamSize`/`maxTeamSize` 1..6; bei 1 = Singles. Keine Kopplung Spielername->Teamname bei Anmeldung.
- **Soll:** Bei Single-Turnier (max Teamgrösse 1) wird bei der Anmeldung der Spielername automatisch als Teamname übernommen und überall (Matches, Brackets, Rankings) angezeigt.
- **Kategorie:** CROSS-FEATURE (Registrierung + Match-/Team-Anzeige) — nicht reiner Wizard.
- **Dateien:** `lib/features/tournament/...` Registrierungs-/Team-Logik, Match-/Bracket-Anzeige. Wizard nur als Auslöser über `teamSize`.

### K09 — Min. Teilnehmer löschen
- **Zeile 200.** Original: *"Das kann gelöscht werden, eine min anzahl müssen wir nicht definieren."*
- **Ziel:** Schritt 2, `minParticipants`.
- **Ist:** `minParticipants` (Default 2, hard min 2) als eigenes `WizardNumberField`; Validierung `>= 2` und `<= maxParticipants`; `_stepValid` participants prüft `minParticipants`.
- **Soll:** Feld + zugehörige Validierung entfernen. `minParticipants` kann intern auf einen fixen Wert (z.B. 2 — das KO-Minimum) gesetzt bleiben, aber kein UI mehr und keine User-Validierung. `_stepValid` participants nur noch über `maxParticipants` (>= 2). Validate() in `draft` entsprechend entschärfen.
- **Kategorie:** WIZARD-UI (+ VALIDIERUNG entfernen).
- **Dateien:** `wizard` (`_StepParticipants`, `_stepValid`), `draft` (`validate()`), evtl. `ctrl.setMinParticipants` bleibt für interne Defaults.

### K10 — Max. Teilnehmer auf 1000
- **Zeile 210.** Original: *"Die max Anzahl an Teilnehmer muss auf 1000 ergänzt werden. Das tournier soll mit max 1000 Teilnehmer funktionieren."*
- **Ziel:** Schritt 2, `maxParticipants` / Konstante `participantsHardMax`.
- **Ist:** `participantsHardMax = 64`; UI-max 64; `validate()` `<= 64`; Controller clamped auf `<= 64`.
- **Soll:** `participantsHardMax = 1000`. UI-max, Validierung und Clamp auf 1000 anheben. (Hinweis: SwissConfigSection `participantSweetSpot=64` bleibt als Warnschwelle bestehen, nicht als Hardlimit.)
- **Kategorie:** NEUES-FELD/DEFAULT (Limit-Änderung).
- **Dateien:** `draft` (`participantsHardMax`), `wizard` (`_StepParticipants`), `ctrl.setMaxParticipants`.

### K11 — KO-Bracket-Grösse von Max-Teilnehmern entkoppeln
- **Zeile 211.** Original: *"Die max anzahl an KO-Bracket-Grösse muss davon nicht abhängen."*
- **Ziel:** Schritt 4 KO-Config, `koConfig.qualifierCount` / Chips-Auswahl.
- **Ist:** Wählbare KO-Grössen = Zweierpotenzen `<= maxParticipants` (`_bracketSizes(participants)` in `ko_step`); `validate` `qualifierCount <= maxParticipants`; `_stepValid` koConfig dito.
- **Soll:** KO-Bracket-Grösse NICHT mehr an `maxParticipants` deckeln. Eigene, feste Obergrenze (z.B. bis 256/512 Zweierpotenzen) anbieten, unabhängig von der Teilnehmerzahl. `KoPhaseConfig.validate` und `_stepValid` entkoppeln (Obere Schranke = eigene Konstante, nicht `maxParticipants`). Beachte Wechselwirkung mit K10 (1000 Teilnehmer, aber Bracket bleibt sinnvoll begrenzt).
- **Kategorie:** WIZARD-UI + VALIDIERUNG (Entkopplung).
- **Dateien:** `ko_step` (`_bracketSizes`, `_isValid`, `_smartDefault`), `draft`/`wizard` (`_stepValid` koConfig), evtl. `KoPhaseConfig.validate` (kubb_domain ko_phase).

### K12 — Gruppenanzahl (Default 4) + Grouping-Strategie in den Vorrunde-Schritt verschieben
- **Zeile 228.** Original: *"Wenn Gruppenphase ausgewählt wird, soll hier die Frage sein, wieviele Gruppen es geben soll. Default wert 4. Die Groupingstrategie soll auch hier festgelegt werden."*
- **Ziel:** Schritt 3 Format (bei `vorrundeType == groupPhase`); betrifft `poolPhaseConfig.groupCount` + `.strategy`.
- **Ist:** Gruppenanzahl (Default 4) + Grouping-Strategie liegen im separaten Schritt 5 (`pool_step`, `WizardPoolConfigStep`), der NACH dem KO-Schritt erscheint.
- **Soll:** Gruppenanzahl-Eingabe (Default 4) + Grouping-Strategie direkt im Format-Schritt unter der Vorrunde-Auswahl anzeigen, sobald Gruppenphase gewählt ist (analog zur `SwissConfigSection` bei Schoch). Die Divisibilitäts-Prüfung (`koBracketSize % groupCount`) hängt am KO-Schritt, der danach kommt — entweder Divisibilität später prüfen oder "Qualifier pro Gruppe" erst im Summary/KO ableiten. Siehe K28 (Schritt 5 möglichst leeren/auslagern).
- **Kategorie:** WIZARD-UI (Feld-Verschiebung) + OFFENE-ENTSCHEIDUNG (Reihenfolge KO vs. Gruppen / wo Divisibilität geprüft wird).
- **Dateien:** `wizard` (`_StepFormat`, `_visibleSteps`, `_StepKind`), `pool_step` (Teile rausziehen), `ctrl.setPoolPhaseConfig`.
- **Empfehlung:** Gruppenanzahl + Strategie in den Format-Schritt; "Qualifier pro Gruppe" + Divisibilitäts-Validierung bleiben abgeleitet und werden im (verschlankten) Pool-/KO-Kontext geprüft. Default `groupCount = 4`.

### K13 — Schoch-Rundendefinition
- **Zeile 237.** Original: *"Eine Runde ist so zu definieren, dass jedes Angemeldete Team eine Begegnung hat mit entweder Bye oder einem anderen Gegner, dann ist die Runde vorbei und es wird die nächste berechnet."*
- **Ziel:** Schritt 3, Schoch-Runden (`SwissConfigSection`, `_swissRounds`) bzw. Pairing-Engine.
- **Ist:** `_swissRounds` ist nur Rundenanzahl (Slider 5..9); keine explizite Runden-Abschluss-Logik im Wizard.
- **Soll:** Definition festhalten/umsetzen: Eine Runde = jedes Team hat genau eine Begegnung (Gegner oder Bye); erst danach wird die nächste Runde berechnet. Betrifft primär die Pairing-Engine, nicht das Wizard-UI. Im Wizard ggf. als Helper-Text dokumentieren.
- **Kategorie:** CROSS-FEATURE (Pairing-Engine) — nicht reiner Wizard.
- **Dateien:** Schoch/Swiss-Pairing-Engine (`lib/features/tournament/...` bzw. `kubb_domain` swiss/schoch), optional `swiss` Helper-Text.

### K14 — Max-Sätze Vorrunde Default 2 (Unentschieden erlaubt)
- **Zeile 287.** Original: *"Max sätze vorrunde soll default 2 sein. In der Vorrunde ist es möglich ein Unentschieden zu spielen."*
- **Ziel:** Schritt 3, `maxSets` (Vorrunden-Matchformat).
- **Ist:** `maxSets` Default `3` (`draft`-Konstruktor); `maxSets` ist bereits von `setsToWin` entkoppelt (gerade Werte/Unentschieden erlaubt, `maxSetsMin=1`).
- **Soll:** Default `maxSets = 2`. Unentschieden bleibt erlaubt (ist schon so). Im `draft`-Konstruktor `maxSets = 2`. Prüfen, dass `fromDetail`-Fallback (`?? 3`) angepasst/konsistent ist.
- **Kategorie:** NEUES-FELD/DEFAULT.
- **Dateien:** `draft` (Default `maxSets`, evtl. `fromDetail`).

### K15 — Model-B-Konfig komplett in den KO-Schritt (keine doppelte Hauptbaumgrösse)
- **Zeile 272.** Original: *"Die Model-B-Konfig soll auch erst im nächsten schritt gemacht werden bei der Ko Config, da wir ansonsten 2x die Hauptbaumgrösse auswählen können. Direkt ins Trostturnier soll auch erst im nächsten Screen wählbar sein. Die Namensgebung für das Trostturnier soll aber da bleiben und required sein. Der name muss dann auch während dem Ko Bracket oben angehängt werden …"*
- **Ziel:** Schritt 3 -> Schritt 4 Verschiebung; Felder `consolationMainBracketSize`, `consolationDirectCount`, `consolationName`.
- **Ist:** `_ConsolationModelBSection` rendert im Format-Schritt (Schritt 3) Hauptbaum-Grösse-Chips (4/8/16/32), Direkt-Starter, Name. KO-Grösse (`qualifierCount`) wird im KO-Schritt nochmals gewählt — doppelte Hauptbaumgrösse (per Lockstep gekoppelt, aber zwei UIs).
- **Soll:**
  1. Hauptbaum-Grösse-Auswahl im Format-Schritt **entfernen** — nur die KO-Grösse im KO-Schritt bleibt als alleinige Quelle (`consolationMainBracketSize` wird aus `qualifierCount` abgeleitet, Lockstep bereits in `ctrl.setKoConfig`).
  2. Direkt-Starter ("Direkt ins Trostturnier") in den KO-Schritt verschieben (siehe K16, als Chips).
  3. **Trostturnier-Name bleibt im Format-Schritt** (oder zieht mit in KO — siehe Hinweis) und wird **required** (nicht mehr optional), sobald `koType == consolation`.
- **Kategorie:** WIZARD-UI (Verschiebung) + VALIDIERUNG/REQUIRED (Name required) + CROSS-FEATURE (Name im KO-Bracket-Header anzeigen, siehe K17).
- **Dateien:** `wizard` (`_StepFormat`/`_ConsolationModelBSection` ausdünnen), `ko_step` (neue Model-B-Sektion), `draft` (`validate()`: consolationName required bei consolation), `l10n`.
- **Hinweis:** Kommentar sagt "Namensgebung soll **da** bleiben" — mehrdeutig (Format-Schritt vs. KO). Empfehlung: Name dort lassen, wo `koType` gewählt wird (Format-Schritt), required machen; nur Grösse + Direkt-Starter wandern in KO.

### K16 — "direkt ins Nebentournier" als Chips
- **Zeile 273.** Original: *"direkt ins nebentournier muss auch die möglichen optionen als Chips anzeigen."*
- **Ziel:** Schritt 4 (nach Verschiebung), `consolationDirectCount`.
- **Ist:** `consolationDirectCount` ist ein freies Zahlen-Textfeld (`_PlainTextField`, `int.tryParse`).
- **Soll:** Als Chip-Auswahl (sinnvolle Werte, z.B. 0 / 4 / 8 / 16 abhängig von Bracket-Grösse) statt Freitext. Werte abgeleitet aus der gewählten Hauptbaum-/KO-Grösse.
- **Kategorie:** WIZARD-UI.
- **Dateien:** `ko_step` (neue Direkt-Starter-Chips), `ctrl.setConsolationDirectCount`.

### K17 — Trostturnier-Name im KO-Bracket-Header anhängen
- **Zeile 272 (Teil).** Original: *"… sagen wir das tournier heisst Sieger der Herzen, dann komme ich ins nebenournier und da muss es dann 'Sieger der gebrochenen Herzen' zb heissen."*
- **Ziel:** KO-Bracket-Anzeige (ausserhalb Wizard); Quelle `consolationName`.
- **Ist:** `consolationName` wird gespeichert, aber im Bracket-Header nicht verwendet.
- **Soll:** Im KO-/Bracket-Screen muss der Nebenturnier-Name (`consolationName`) oben im Header des Trost-Brackets angezeigt werden.
- **Kategorie:** CROSS-FEATURE (Bracket-/Turnier-Detail-Screen) — nicht reiner Wizard.
- **Dateien:** `lib/features/tournament/presentation/...` Bracket-/Detail-Header.

### K18 — KO-Grösse: ggf. Nebenturnier-Anzahl wählen
- **Zeile 348.** Original: *"Hier muss eben allenfalls noch die NebenTournier Anzahl ausgewählt werden."* (unter [KO-Grösse/Qualifier]).
- **Ziel:** Schritt 4 KO-Config; Zusammenhang mit Model-B-Verschiebung (K15/K16).
- **Ist:** Im KO-Schritt nur `qualifierCount` (KO-Grösse) + Seeding + Per-Runden-Regeln; keine Nebenturnier-Grösse.
- **Soll:** Wenn `koType == consolation`: hier zusätzlich die Nebenturnier-Grösse/-Anzahl wählbar machen (zusammen mit K15/K16 als Model-B-Block im KO-Schritt). Bei anderen KO-Typen nicht anzeigen.
- **Kategorie:** WIZARD-UI (Teil des Model-B-Umzugs).
- **Dateien:** `ko_step`, `ctrl` (Model-B-Setter).

### K19 — Seeding-Quelle: manuell während Turnier?
- **Zeile 357.** Original: *"Was passiert wenn es manuell festgelegt wird während des Tourniers? also pop da denn ein Screen beim Veranstalter auf bitte mach das seeding oder wie?"*
- **Ziel:** Schritt 4, `bracketSeedingMode` / `SeedingMode.manual`.
- **Ist:** `SeedingMode.manual` wird gespeichert; kein definiertes Verhalten beim Turnierstart.
- **Soll:** Verhalten festlegen: Bei `manual` muss zum Bracket-Aufbau ein Seeding-Screen beim Veranstalter erscheinen (vor KO-Start).
- **Kategorie:** OFFENE-ENTSCHEIDUNG (+ später CROSS-FEATURE bei Umsetzung).
- **Dateien:** Entscheidungsdoc + später `lib/features/tournament/...` (Seeding-Flow).
- **Empfehlung:** Ja — bei `manual` beim Übergang Vorrunde->KO ein Pflicht-Seeding-Modal/-Screen für den Organisator (blockiert KO-Start bis Seeding gesetzt). Dokumentieren, Umsetzung als eigener Cross-Feature-Block.

### K20 — Seeding bei "beste vs schlechteste"/"1 vs 2" ausblenden?
- **Zeile 358.** Original: *"Also das Seeding denke ich müsste garnicht drin sein wenn man auswählt beste vs schlechteste oder 1 vs. 2. oder? Wnn ja nimm es raus wenn nein, lass es drin."*
- **Ziel:** Schritt 4, Beziehung `koMatchup` (seedHighVsLow/oneVsTwo) <-> `bracketSeedingMode`.
- **Ist:** Seeding-Quelle (auto/manual) und KO-Matchup sind unabhängig, beide immer sichtbar.
- **Soll:** Entscheid, ob die Seeding-Quelle bei gewähltem `koMatchup` (beide Varianten setzen ein Seeding voraus) noch nötig ist.
- **Kategorie:** OFFENE-ENTSCHEIDUNG.
- **Empfehlung:** Beibehalten ("lass es drin"). Begründung: `koMatchup` bestimmt nur das Paarungsmuster; die Seeding-Quelle (auto aus Vorrunde vs. manuell) bestimmt, **woher** die Rangliste kommt — beide Matchups brauchen eine Setzliste. Daher Seeding-Quelle nicht ausblenden.

### K21 — KoMatchup: SegmentedButton -> Radio-Buttons
- **Zeile 368.** Original: *"hier gefällt mir das UI nicht, mache das bitte so wie die anderen Radio Buttons."* (unter [KO-Matchup]).
- **Ziel:** Schritt 4, `koMatchup`.
- **Ist:** `SegmentedButton<KoMatchup>` in `ko_step` (`_phase3Sections`).
- **Soll:** Auf `RadioGroup`/`RadioListTile` umstellen, konsistent mit `_SeedingModeRadios` (gleiche Optik wie übrige Radios).
- **Kategorie:** WIZARD-UI.
- **Dateien:** `ko_step` (`_phase3Sections`, KoMatchup-Block).

### K22 — KoTiebreakMethod: SegmentedButton -> Radio-Buttons
- **Zeile 378.** Original: *"hier gefällt mir das UI nicht, mache das bitte so wie die anderen Radio Buttons."* (unter [KO-Tiebreak-Methode]).
- **Ziel:** Schritt 4, `koTiebreakMethod`.
- **Ist:** `SegmentedButton<KoTiebreakMethod>` in `ko_step`.
- **Soll:** Auf Radio-Buttons umstellen (wie K21).
- **Kategorie:** WIZARD-UI.
- **Dateien:** `ko_step` (`_phase3Sections`, KoTiebreak-Block).

### K23 — Pitch-Zuteilung pro Gruppe direkt hier konfigurieren
- **Zeile 325.** Original: *"wenn das gewählt wird & GruppenPhase gewählt ist, soll dies auch direkt hier konfiguriert werden."* (unter [Manuelle Reihenfolge]/Pitches).
- **Ziel:** Schritt 3 Pitches (`_PitchPlanSection`) vs. Schritt 5 Pitch-Gruppenzuteilung.
- **Ist:** `pitchPlan.groupAssignment` (Pitch je Gruppe) wird erst im Pool-Schritt (Schritt 5) gesetzt, nicht im Pitch-Abschnitt.
- **Soll:** Wenn Gruppenphase gewählt ist, die Pitch-Gruppenzuteilung direkt im Pitch-Kontext konfigurieren. Hängt eng mit K12 (Gruppen in Format-Schritt) und K24 (Pitches auslagern) zusammen.
- **Kategorie:** WIZARD-UI + OFFENE-ENTSCHEIDUNG (wo genau, da K24 Auslagerung verlangt).
- **Dateien:** `wizard` (`_PitchPlanSection`), `pool_step` (`_pitchAssignmentSection`).
- **Empfehlung:** Zusammen mit K24 in den ausgelagerten Pitch-Screen ziehen; Gruppenzuteilung dort anbieten, sobald Gruppenphase + Pitches existieren.

### K24 — Pitches/Felder-Config (inkl. Gruppen-Pitch) in separaten Screen auslagern
- **Zeile 327.** Original: *"LAgere Die Pichtes und felder Config inklusive der allfälligen Pitchkonfig der Gruppe in einen Separaten Screen aus."*
- **Ziel:** Schritt 3 Pitch-Abschnitt + Schritt 5 Pitch-Gruppenzuteilung.
- **Ist:** Pitch-Plan inline im Format-Schritt (`_PitchPlanSection`); Gruppenzuteilung im Pool-Schritt.
- **Soll:** Gesamte Pitch-/Feld-Konfiguration (Modus, Bereich/Nummern, Sortierung, manuelle Reihenfolge, Gruppen-Pitch-Zuteilung) in einen eigenen Screen auslagern (vom Format-Schritt aus aufrufbar, "Pitches konfigurieren ->").
- **Kategorie:** WIZARD-UI (grössere Umstrukturierung).
- **Dateien:** Neuer Screen `lib/features/tournament/presentation/...` (Pitch-Config), `wizard` (`_PitchPlanSection` rausziehen + Einstiegspunkt), `pool_step` (`_pitchAssignmentSection` mitnehmen).

### K25 — Schritt 5: sind alle Funktionen ausgelagert?
- **Zeile 441.** Original: *"sind hier alle funktionen aufgelöst besser gesagt ausgelagert an andere screens?"* (im Gruppenphase-Schritt).
- **Ziel:** Schritt 5 `WizardPoolConfigStep`.
- **Ist:** Schritt 5 enthält Gruppenanzahl, abgeleitete Qualifier/Gruppe, Grouping-Strategie, Random-Seed, Pitch-Gruppenzuteilung.
- **Soll:** Nach K12 (Gruppen+Strategie -> Format) und K23/K24 (Pitch-Gruppe -> Pitch-Screen) soll Schritt 5 möglichst leer/aufgelöst werden. Prüfen, ob der Schritt ganz entfallen kann (dann `_StepKind.poolConfig` + `_visibleSteps` entfernen). Verbleibend: nur abgeleitete "Qualifier pro Gruppe"-Anzeige — könnte in Summary wandern.
- **Kategorie:** WIZARD-UI + OFFENE-ENTSCHEIDUNG (Schritt 5 entfernen ja/nein).
- **Dateien:** `wizard` (`_StepKind`, `_visibleSteps`), `pool_step`.
- **Empfehlung:** Schritt 5 nach Verschiebung von Gruppen/Strategie/Pitch ganz entfernen; "Qualifier pro Gruppe" read-only in den Summary-Schritt aufnehmen.

### K26 — Summary: alles sichtbar + Fehler markiert
- **Zeile 458.** Original: *"Hier soll nochmals alles sichtbar sein. und auch mit den fehlern markiert werden wenn sich das tournier nicht anlegen lässt."*
- **Ziel:** Schritt 6 `_StepSummary`.
- **Ist:** `_StepSummary` zeigt nur 7 Felder (Name, Min/Max Teilnehmer, Format, Sätze zum Sieg, Max Sätze, Rundenzeit); keine Fehleranzeige (Button nur disabled über `validate().isValid`).
- **Soll:** Summary muss ALLE konfigurierten Werte aller Schritte anzeigen. Zusätzlich: Wenn `validate().isValid == false`, die `issues()`-Liste sichtbar als Fehlermarkierungen anzeigen (welche Felder/Constraints blockieren das Anlegen).
- **Kategorie:** WIZARD-UI.
- **Dateien:** `wizard` (`_StepSummary` ausbauen, `draft.validate().issues` rendern).

### K27 — Global: alle nicht-optionalen Felder required
- **Zeile 483.** Original: *"Alle Felder welche jetzt nicht explizit als Optional sind müssen required sein ausser sie sind durch eine funktion nicht eingeblendet."*
- **Ziel:** Global, alle Schritte. Betroffen u.a.: K03 (Verein), K15 (consolationName), und alle aktuell als `optional: true` markierten Felder neu bewerten.
- **Ist:** Viele Felder explizit `optional: true` (Verein, Liga, Ort, Adresse, Daten, Gebühr, Kontakt, Infos, PDFs, consolationName). `validate()` erzwingt nur einen Teil.
- **Soll:** Globale Regel: Jedes Feld, das NICHT bewusst als optional gekennzeichnet bleiben soll, wird required (Validierung + UI-Markierung), sofern es im aktuellen Flow eingeblendet ist (durch Funktion ausgeblendete Felder ausgenommen). Erfordert pro Feld einen Entscheid optional ja/nein (siehe K28–K33 für die einzeln markierten). Konkrete Pflicht-Kandidaten laut Kommentaren: Ort, Adresse, Turnierstart, Anmeldeschluss, Check-in, Verein.
- **Kategorie:** VALIDIERUNG/REQUIRED (+ OFFENE-ENTSCHEIDUNG: welche Felder bleiben optional).
- **Dateien:** `draft` (`validate()`), `wizard` (`optional`-Badges, `_stepValid` je Schritt), `l10n`.
- **Empfehlung:** Liste der optionalen Felder durchgehen; Standort/Adresse/Daten als required (Kommentare K30–K33), PDFs/Kontakt/Infos/Gebühr realistisch optional lassen (Entscheid mit User). Pro Feld in Summary-Fehlern (K26) sichtbar machen.

### K28 — Alle Wizard-Infos in Turnier-Details einsehbar + PDFs downloadbar
- **Zeile 484.** Original: *"Alle infos die hier im gesamten Wizard configuriert werden sollen dann später in den Tournierdetails einsehbar sein. Die eventuell hochgeladenen PDFs sollen dann dort einfach herunterladbar sein."*
- **Ziel:** Turnier-Detail-Screen (ausserhalb Wizard); Quelle: gesamtes `toSetupConfig`/`p_match_format_config`.
- **Ist:** Detail-Screen zeigt nur einen Teil; PDF-Download-UI im Detail unklar/fehlend.
- **Soll:** Turnier-Details müssen alle Wizard-Konfigurationen anzeigen; `rulesPdfUrl`/`siteMapPdfUrl` als Download-Links/Buttons.
- **Kategorie:** CROSS-FEATURE (Turnier-Detail-Screen) — nicht reiner Wizard.
- **Dateien:** `lib/features/tournament/presentation/...` (Detail-Screen).

### K29 — "Liga-Kategorien" nicht optional, wenn kein Spasstournier
- **Zeile 79.** Original: *"Die darf nicht Optional sein wenn es kein SpassTournier ist. das PunkteSystem muss andocken können an die Liga."*
- **Ziel:** Schritt 1, `leagueCategories` (nur sichtbar bei `clubId != null`).
- **Ist:** Multi-Select A/B/C, optional, nur bei gesetztem Verein sichtbar; bei `clubId == null` immer leer.
- **Soll:** Wenn ein Verein gewählt ist (kein Spasstournier), mind. eine Liga-Kategorie required. Bei Spasstournier (`clubId == null`) bleibt es leer/ausgeblendet (durch Funktion ausgeblendet -> Ausnahme von K27). Punktesystem dockt an Liga an.
- **Kategorie:** VALIDIERUNG/REQUIRED (bedingt) + CROSS-FEATURE (Punktesystem<->Liga).
- **Dateien:** `draft` (`validate()`: `leagueCategories` nicht leer wenn `clubId != null`), `wizard` (Badge), `l10n`.

### K30 — "Ort" darf nicht optional sein
- **Zeile 87.** Original: *"Das Darf auch nicht optional sein."* (unter [Ort]).
- **Ziel:** Schritt 1, `location`.
- **Ist:** optional, blank->null; keine Validierung.
- **Soll:** required (nicht leer). `optional`-Badge entfernen, `validate()`-Check, `_stepValid` name-Step.
- **Kategorie:** VALIDIERUNG/REQUIRED.
- **Dateien:** `draft` (`validate()`), `wizard` (`_StepStammdaten`).

### K31 — "Adresse" darf nicht optional sein
- **Zeile 94.** Original: *"Das Darf auch nicht optional sein."* (unter [Adresse]).
- **Ziel:** Schritt 1, `venueAddress`.
- **Ist:** optional, blank->null.
- **Soll:** required (nicht leer).
- **Kategorie:** VALIDIERUNG/REQUIRED.
- **Dateien:** `draft` (`validate()`), `wizard`.

### K32 — "Turnierstart" darf nicht optional sein
- **Zeile 102.** Original: *"Das Darf auch nicht optional sein."* (unter [Turnierstart]).
- **Ziel:** Schritt 1, `eventStartsAt`.
- **Ist:** optional; Constraint nur Anmeldeschluss < Turnierstart.
- **Soll:** required (Datum+Zeit muss gesetzt sein).
- **Kategorie:** VALIDIERUNG/REQUIRED.
- **Dateien:** `draft` (`validate()`), `wizard`.

### K33 — "Anmeldeschluss" + "Check-in bis" dürfen nicht optional sein
- **Zeilen 110 + 117.** Original (2×): *"Das Darf auch nicht optional sein."* (unter [Anmeldeschluss] bzw. [Check-in bis]).
- **Ziel:** Schritt 1, `registrationClosesAt` und `checkinUntil`.
- **Ist:** beide optional; Constraint Anmeldeschluss < Turnierstart.
- **Soll:** beide required (gesetzt). Bestehende Reihenfolge-Constraints beibehalten (Anmeldeschluss < Start; sinnvoll auch Check-in-Bezug prüfen).
- **Kategorie:** VALIDIERUNG/REQUIRED.
- **Dateien:** `draft` (`validate()`), `wizard`.

---

## Block-Gruppierung für die Umsetzung

So gewählt, dass Blöcke möglichst NICHT dieselben Dateien gleichzeitig anfassen. CROSS-FEATURE-Blöcke sind klar als "nicht reiner Wizard" markiert; OFFENE-ENTSCHEIDUNG braucht zuerst einen Entscheid.

- **Block 1 — Stammdaten-Required & Felder/Defaults (Schritt 1).** K03, K06, K07, K27 (Stammdaten-Teil), K29, K30, K31, K32, K33 + Label-Rename K02 + K01. Hauptdateien: `wizard` (`_StepStammdaten`), `draft` (`validate()`, Defaults), `domain` (`RuleVariants.diggy`=K05), `l10n`.
- **Block 2 — Teilnehmer & Limits (Schritt 2).** K09 (Min löschen), K10 (Max 1000), K08-Trigger. Dateien: `wizard` (`_StepParticipants`), `draft` (`participantsHardMax`, `validate()`), `ctrl`.
- **Block 3 — KO-UI & Model-B-Umzug (Schritt 3->4).** K11 (Entkopplung), K15, K16, K18, K21, K22. Dateien: `ko_step`, `wizard` (`_StepFormat`/`_ConsolationModelBSection`), `ctrl`. (K14 Default `maxSets=2` kann hier oder in Block 1 mitlaufen — nur `draft`-Default.)
- **Block 4 — Vorrunde/Gruppen + Pitch-Auslagerung & Schritt-5-Abbau.** K12, K23, K24, K25. Dateien: `wizard` (`_StepFormat`, `_PitchPlanSection`, `_StepKind`/`_visibleSteps`), `pool_step`, neuer Pitch-Screen. (Berührt `_StepFormat` -> nicht parallel zu Block 3 ausführen.)
- **Block 5 — Summary (Schritt 6).** K26 + K27 (Summary-Fehleranzeige). Dateien: `wizard` (`_StepSummary`), `draft.validate()` (nur lesen).
- **Block 6 — CROSS-FEATURE Punktesystem/Matches (nicht reiner Wizard).** K02 (Wertungslogik), K04 (Scoring->MatchScreen), K08 (Single-Name->Teamname), K13 (Schoch-Rundenlogik), K17 (Trostname im Bracket-Header). Dateien: `lib/features/match/...`, Registrierung/Team, Pairing-Engine, Bracket-Header.
- **Block 7 — CROSS-FEATURE Turnier-Details (nicht reiner Wizard).** K28 (alle Infos im Detail + PDF-Download). Dateien: Turnier-Detail-Screen.
- **OFFENE-ENTSCHEIDUNG (braucht Entscheid vor Umsetzung).** K12 (Reihenfolge KO/Gruppen + wo Divisibilität), K19 (manuelles Seeding-Screen), K20 (Seeding ausblenden), K23 (wo Pitch-Gruppe), K25 (Schritt 5 ganz entfernen), K27/K29 (welche Felder optional bleiben).
