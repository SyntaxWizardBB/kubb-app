# Status-Abgleich — ProjectPlan.txt ↔ Code-Stand

> **Quelle der Wahrheit bleibt `ProjectPlan.txt`.** Dieses Dokument ist die lebende
> Status-Übersicht dazu. Stand: **2026-06-09**.
> Legende: ✅ umgesetzt · 🟡 angefangen/Gerüst · 🔄 gerade in Umsetzung · ❌ offen · ⚠️ nicht auditiert.

---

## ✅ Milestone GEBAUT (Code+Tests): Veranstalter-Dashboard & zeitgesteuerter Turnier-Ablauf (A–E)

Autonom über die Agent-Pipeline umgesetzt (Branch `feat/tournament-scheduler-dashboard`, alle 27 Blöcke
committet+gepusht). Architektur: ADR-0031. Pläne: `KubbProj/docs/plans/tournament-scheduler-dashboard/`.
**Verifiziert:** analyze sauber (Milestone-Dateien), Tests grün (kubb_domain 633, tournament+inbox 687),
17 Migrationen angewandt, cron-Job aktiv. **NOCH offen:** Live-Verifikation in der App; **nicht** in main gemergt.

| Phase | Inhalt | Stand |
|---|---|---|
| **A** | Schedule-Engine + skew-korrigierte Sync-Uhr | ✅ komplett (6/6) |
| **B** | Veranstalter-Dashboard (Multi-Turnier, Start/Pause/Skip), referee=Turnier-Admin | ✅ komplett (7/7) |
| **C** | Notifications bei Schedule-Events (durable Inbox + getaktet) | ✅ komplett (5/5) |
| **D** | Vor-Ort-Check-in + Eskalations-Panel + No-Show→Forfait | ✅ komplett (5/5) |
| **E** | pg_cron-Autonomie-Tick (geräteunabhängiger Ablauf) | ✅ komplett (4/4) |
| Cleanup | Dead-Code/Security/Overflows/UX/Bugs/Messaging-Scan + sichere Fixes | ⏸️ AUSGEKLAMMERT — separater Flow, vorab mit User spezifizieren |

Deckt aus dem ProjectPlan ab: **BUG3 Veranstalter-Dashboard/Vor-Ort-Checkin**, die **Uhr-/Realtime-**
Anforderung (UI-Ruleset R1/R2), **Pausen-/Ablauf-Management**.

---

## UI-Ruleset (für CLAUDE.md)

| Punkt | Stand | Anmerkung |
|---|---|---|
| R1 +/- Counter + manuelle Zahleneingabe im Match | ✅ | Score-Screens haben beides |
| R2 Jedes DB-Event → Message an Betroffene | 🟡→🔄 | CDC + Inbox vorhanden; Schedule-Events jetzt via Phase C; **nicht systematisch auditiert** (Cleanup-Scan „Messaging" prüft das) |
| R3 Alle Eingabefelder beschriftet | ⚠️ | Info-Button-Muster da (KO-Setup); nicht flächendeckend geprüft |

## MilestoneBerechtigungskonzept

| Punkt | Stand | Anmerkung |
|---|---|---|
| B1 „Meine Vereine" → „Veranstalter", code-gated (JH5U-QZ4L) | ❌ | Kachel nicht umbenannt/gated; Code setzt nur `can_found_clubs` |
| B2 Rollen konsolidieren; referee = Turnier-Admin | 🟡 | **Teilfortschritt:** referee jetzt im Manage-Gate (Dashboard B1s) → darf Turniere administrieren. Volle Konsolidierung (Mitglied/Timemaster/… entfernen) noch offen |
| B3 Rolle beim Hinzufügen wählbar | ❌ | nur nachträglich per Dialog; Team nur member/guest |
| B4 „MatchModus"-Kachel → „laufendes Match"-Kachel | ❌ | Provider `my_active_match_provider` existiert, keine Hub-Kachel |

## MilestoneTestingSuite

| Punkt | Stand | Anmerkung |
|---|---|---|
| T1 BugHunt „Resultate eintragen" | ✅ (Veranstalter) | Organizer-Override war toter Code → Einstieg+Gate+RPC gefixt (`65f2837`, Branch `fix/t1-organizer-score-override`, gepusht). **Offen:** Spieler-Pfad-Repro mit 2 Emulatoren |
| T2 Testszenarien 30–60 Spieler, alle Configs | ❌ | noch nicht entworfen |
| T3 weitere Integrationstests | ❌ | |

## Milestone: MultiDevice/Responsive

| Punkt | Stand | Anmerkung |
|---|---|---|
| Tablet-/adaptive Layouts | ❌ | Mobile-only, keine Breakpoints |

## LastMilestonePublishApp

| Punkt | Stand | Anmerkung |
|---|---|---|
| PushNotifications/PushProvider | 🟡 | nur Seam/Stub (`inbox_push_seam`); echtes FCM/Edge fehlt |
| Server für Supabase (Prod) | ❌ | |
| OAuth Provider (Google/Apple) | ✅ | `sign_in_screen`, `account_link_screen` |
| Builds in Appstores | ❌ | |
| Publication-Risiko (CDC ADR-0029) | ✅ verstanden | jede CDC-Tabelle bringt ALTER PUBLICATION + RLS mit (Muster etabliert) |
| Storage deaktiviert / Prod-Migration ohne Reset | ❌ offene Fragen | noch zu klären |

## Milestone features

| Feature | Stand | Anmerkung |
|---|---|---|
| MatchClock | ✅→🔄 | vorhanden; durch Phase A jetzt server-verankert + skew-korrigiert |
| SpassTournier (aus Wertung) | ✅ | `club_id IS NULL` → excluded |
| Badges/Achievements | 🟡 | Skeleton-UI + Drift-Repo; finale Glyphs fehlen |
| Söldnermarket | 🟡 | „Coming-Soon"-Platzhalter |
| AdminDashBoard (app-weiter Support, User-Rechte) | 🟡 | nur Saison-Admin; **abgegrenzt** vom Veranstalter-Dashboard (eigener Milestone) |
| liveCam | ❌ | |

## BUGS

| Bug | Stand | Anmerkung |
|---|---|---|
| BUG1 Training-Stats detaillierter (Sniper Heli-Quote …) | ✅ | `f052aed` |
| BUG2 Namen gegen DB prüfen (Profil/Team/Verein) | ✅ | `3293b69` |
| BUG3a KO-Regeln in Details, „Strafkubb"-Umbenennung, schnellerer Roster | ✅ | `818f223` |
| BUG3b Vor-Ort-Checkin / Veranstalter-Dashboard | 🔄 | wird in Phase B/D gebaut |

## DONE??? (bestätigt umgesetzt)

| Bereich | Stand |
|---|---|
| MilestoneTourierHUB (Live/Künftige, 3-Tab-View, Info-Button, Stammdaten-Karte, echte Namen) | ✅ |
| MilestoneTournaments V2 (konfigurierbare Sätze, Edit-nach-Veröffentlichung + Neuberechnung) | ✅ |
| MilestoneRanglisten (Turnier-Statistik Serie+H2H, Stage-Graph, Personal-/Trainings-ELO) | ✅ |

---

## TODOOS (aus ProjectPlan, noch offen)

- Deployment-Features (Push, MatchClock) — Push ❌, MatchClock ✅
- Alle Tournier-Config-Möglichkeiten durchgehen + beschreiben + Alt-Code-Check — ❌ (Teil des Cleanup-Scans)
- Alle Configs beschreiben → in Turnierdetails — 🟡 (Stammdaten-Karte deckt viel ab)
- UI überarbeiten (ASCII aller Screens nötig) — ❌
- Aufräumen (Agent-Workflows Dead-Code/Clean/Security/Overflows/UX/Bugs/Messaging) — 🔄 (Cleanup-Phase des laufenden Builds)

### Mein Vorgehen (geplante Reihenfolge)

1. Push-Benachrichtigungen einweben
2. OAuth Provider einweben
3. SupaBase vorbereiten/verbinden
4. Info-Buttons machen
5. Testing Suite & Tests
6. UI konsolidieren/vereinheitlichen/MultiDevice
7. Workflows erstellen
8. Features entwickeln

---

## Branch-Lage (Stand 2026-06-10 — konsolidiert)

**Alles in `main` gemergt + gepusht** (`579164d`). Volle Suite 1417 grün, analyze clean.
- `feat/skv-tour-points` Folge-Feinschliff (Turnierstatistik Serie+H2H, Stage-Graph
  double_elim/consolation/swiss-Generierung, Tiebreaker-Parität, Multi-Root) — in main.
- `feat/spass-tournament-invite` — Spaßturnier „auf Einladung" (Server: invite_only,
  tournament_invitations, RLS/Sichtbarkeit, Invite/Respond/Revoke-RPCs, Inbox-Kind;
  Client: Wizard-Schalter+Spielersuche, Inbox-Annehmen/Ablehnen) — in main.
- `feat/tournament-scheduler-dashboard` — ADR-0031 A–E (Veranstalter-Dashboard,
  Vor-Ort-Checkin, Schedule-Notifications, pg_cron-Tick) — in main gemergt.
  ⚠️ **Live-/On-Device-Verifikation weiterhin offen** (Code+Tests grün, aber kein
  realer Durchklick); BUG3b damit code-seitig erledigt, Abnahme ausstehend.
- `fix/t1-organizer-score-override` — T1 Organizer-Score-Eintrag — in main gemergt.
  Offen bleibt nur die Spieler-Pfad-Repro mit 2 Emulatoren.
