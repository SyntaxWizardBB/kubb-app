# Tournament-Hub Milestone — V1-Plan (Anzeige/UX + Score-Konsens-Bugfix)

**Status:** Plan — fertig zur Umsetzung, wartet auf Startsignal.
**Quelle:** humanPlan/MilestoneTourierHUB.txt (Teil A + `#`-Kommentare) + Code-Diagnose.
**Abgrenzung:** V1 = Anzeige/UX + EIN Bugfix. Das Turnier-**Regelwerk** (Formate, KO-Modelle,
Per-Runde-Sätze, Edit-nach-Publish …) ist **V2** (eigener Plan: MilestoneTournamentHub_V2_Plan.md).
**Arbeitsweise:** blockweise über die 4-Rollen-Pipeline (docs/AGENT_PIPELINE_PLAYBOOK.md),
je Block: DoD → Implement → Review → Improve, danach unabhängig verifizieren + ein Commit/Block.

## Geklärte Entscheidungen
- **A1 Mehrfach-Live:** genau 1 Live-Turnier → direkt in die 3-Reiter-Ansicht; mehrere → kurze
  Auswahlliste; keine → Leerzustand.
- **A2 Künftig-Filter:** `event_starts_at >= heute 00:00`; Turniere ohne Datum (NULL) werden
  trotzdem gezeigt (als undatiert/anstehend). Laufende (live) gehören NICHT hierher (→ A1).
- **N1 Rundendauer:** die KONFIGURIERTE Rundenzeit (`time_limit_seconds`/`round_time_minutes`)
  wird in den Turnier-Meldungen genannt (nicht die tatsächlich verstrichene Zeit).
- **Score-Bug-Symptom (bestätigt):** „Konsens hängt / disputed“.
- **Branch-Basis:** zur Umsetzungszeit festzulegen (aktuell aktive Branches: feat/p6-tournament-setup,
  feat/skv-tour-points, feat/realtime-sync). V1 baut auf dem aktuellen Tournament-Mainline auf.

---

## Block M2 — Score-Konsens-Bugfix  (zuerst; Client + DB-Migration)

**Problem (read-only diagnostiziert, 2 Agenten, konsistent):** Sätze ohne sauberes
„König-Outcome / Sieger=`none`“ werden inkonsistent über Client→Wire→Server→Konsens geführt →
falsche Einig/Uneinig-Entscheidung → Match läuft bis consensus_round 3 → disputed.

Befunde:
1. Client erzwingt immer A oder B, auch bei König-Timeout/„Keiner“ (`king==null` → Sieger nach
   Kubb-Zahl) — `lib/features/tournament/presentation/tournament_match_detail_screen.dart:139`.
   `SetWinner`-Enum hat kein `none`.
2. `_setScoreToWire` 2-Wege-Ternär (`teamA ? 'A' : 'B'`) — `'none'` unmöglich —
   `lib/features/tournament/data/tournament_repository.dart:1163`. Server erwartet A/B/none.
3. Konsens-Vergleich ignoriert `set_king_outcome` —
   `supabase/migrations/20260615000007_score_rpc_team_patch.sql:293`.
4. Array-RPC `tournament_propose_set_scores` speichert `set_king_outcome` nicht (Spalte existiert,
   INSERT fehlt) — gleiche Migration ~Z. 179.
5. König-Wahl geht beim Reload verloren: `setSets()` persistiert `kingOutcome` nicht —
   `lib/features/tournament/application/tournament_score_draft_controller.dart:100`.
6. `clear()` blockiert Re-Init (hydratedForRound falsch gesetzt) — ebd. ~Z. 115 (minor).
7. Client deckelt Basiskubbs auf 5, Server-CHECK 0..6 — match_detail_screen.dart:58 (config-abhängig).

**Lösung (kanonisches Satz-Ergebnis, konsistent über die ganze Kette):**
- Ein KANONISCHES Satz-Ergebnis definieren, das König-Outcome (HitBy A/B, Missed, TimedOut) UND
  Sieger inkl. `none` trägt; client- und serverseitig DETERMINISTISCH identisch aus denselben
  Eingaben abgeleitet, sodass zwei reale, gleiche Eingaben IMMER „einig“ ergeben.
- Client: bei König-Timeout/„Keiner“ den Sieger korrekt als `none` (bzw. nach der bestätigten
  Regel, siehe OFFENER PUNKT) führen; `SetWinner` um `none` erweitern ODER Sieger aus
  King-Outcome+Kubbs kanonisch ableiten. `_setScoreToWire` deckt A/B/none ab.
- Server: Array-RPC speichert `set_king_outcome`; Konsens-Vergleich nutzt das KANONISCHE Ergebnis
  (entweder king_outcome mitvergleichen oder den kanonisch abgeleiteten Sieger), sodass gleiche
  Realität = einig. Additive Migration (CREATE OR REPLACE der RPC, auf AKTUELLER Definition basieren,
  Stale-Body per Diff ausschließen). Timestamp nach aktuell jüngster Migration.
- Client: `kingOutcome` im Draft persistieren (setSets) + beim init wiederherstellen; `clear()` so,
  dass die nächste init wirklich neu lädt; Basiskubb-Range aus der Turnier-Config (basekubbs_per_side)
  statt hart 5.
- **Tests:** Konsens-Einig/Uneinig je King-Outcome (insb. Timeout/none beidseitig → einig);
  Draft-Persistenz inkl. King-Outcome über Rebuild; Range aus Config; bestehende Score-Tests grün.
  Server: BEGIN..ROLLBACK-pgTAP/psql-Proben für die Konsens-RPC.

**KANONISCHE SATZ-/MATCH-REGEL (vom User geklärt — PHASEN- + modus-abhängig):**
Der heutige Bug ist der naive Fallback „Sieger nach Kubb-Mehrheit, wenn kein König" — in BEIDEN
Phasen falsch. Richtig:
- **GRUPPENPHASE — KEIN Finisher, Unentschieden erlaubt:**
  - Classic: Match = gewonnene Sätze (Satz nur gewonnen, wenn König fiel); Stände wie 1:1, 2:1, 2:2;
    läuft die Zeit ab und ein Satz hat keinen König → dieser Satz = `none` (zählt nicht), Stand bleibt
    (1:1 ist gültiges Endergebnis).
  - EKC: Match = gezählte Kubbs (8:16, 8:8, 13:13 …); kein Finisher; Unentschieden (8:8) bleibt stehen.
- **KO-PHASE — Finisher entscheidet bei Zeitablauf:**
  - König nicht gefallen (Zeit aus, z.B. erst 2 Kubbs im 3. Satz) → der KONFIGURIERTE Finisher
    (`ko_tiebreak_method`: klassisch / Mighty-Finisher) wird gespielt; das Display fragt
    **„Wer hat den Finisher gewonnen?"** → daraus Satz-Sieger → Match z.B. 2:1 / 1:2. KEIN Unentschieden im KO.
Folge: kanonisches Ergebnis wird PHASEN- + modus-abhängig abgeleitet, IDENTISCH auf Client UND Server →
gleiche Realität = „einig" (behebt den Konsens-Bug). Der Konsens vergleicht das kanonische Ergebnis
(inkl. Finisher-Ausgang im KO).

**Dateien:** packages/kubb_domain (SetWinner/Set-Ergebnis), match_detail_screen.dart,
tournament_repository.dart (_setScoreToWire), tournament_score_draft_controller.dart, tournament_set_input.dart,
neue Migration (Konsens-RPC + array-RPC king_outcome), Tests.

---

## Block H1 — Hub-Kacheln + Routen: „Live“ / „Künftige“

- „Angemeldete Turniere“ → **„Live Turniere“**: Inhalt = myRegistrations ∩ status==live.
  Genau 1 → direkt in die 3-Reiter-Live-Ansicht (Block H3); mehrere → kurze Auswahlliste; keine → Leerzustand.
  Piktogramm/Icon anpassbar.
- „Aktuelle Turniere“ → **„Künftige Turniere“**: Discovery-Liste, zusätzlich Datums-Filter
  `event_starts_at >= heute 00:00 OR event_starts_at IS NULL`; live raus (sind unter Live).
- **Dateien:** tournament_hub_screen.dart, tournament_list_screen.dart,
  tournament_registrations_screen.dart, tournament_routes.dart, l10n (Labels).
- **Verifikation:** Provider-/Widget-Tests für die Filter + Navigations-Verzweigung (1 vs n live).

## Block H2 — Stammdaten verdichtet + Repo-Regel

- Gemeinsames **Stammdaten-Widget**, das ALLE konfigurierten Turnier-Stammdaten kompakt & schön
  darstellt (B3.1–B3.4: Format, Team-Größe, Sätze/Max-Sätze, Rundenzeit, Tiebreak/Mighty-Finisher,
  KO-Modell, Scoring, P6-Metadaten Location/Fees/Zahlarten/Regeln-PDF/… soweit gesetzt).
- Einsatz: im **Künftige-Turniere-Detail** (Kommentar Z. 37) UND im normalen Turnier-Detail
  (Kommentar Z. 116: „immer alle Stammdaten“).
- **Repo-Regel:** in KubbProj/CLAUDE.md verankern: „Turnier-Detail bildet IMMER alle gesetzten
  Stammdaten ab (kein stilles Weglassen konfigurierter Felder).“
- **Dateien:** neues widgets/tournament_stammdaten_card.dart, tournament_detail_screen.dart, CLAUDE.md.
- **Verifikation:** Widget-Test (alle gesetzten Felder erscheinen; ungesetzte werden ausgelassen);
  Golden/Layout nach Design-System.

## Block H3 — 3-Reiter-Live-Ansicht

- Neuer TabBar-Screen, Default-Reiter **„Mein Match“**:
  1. **Mein Match** — aktuelle(s) nicht-terminale(s) Match(es) des Spielers → Score-Eingabe.
  2. **Übersicht** — komplette Match-Liste nach Runden (Inhalt von „Zu den Matches“).
  3. **Rangliste** — Live-Standings.
  AppBar-Action oben rechts **„Turnier-Infos“** → Turnier-Detail (Stammdaten, H2).
- **Dateien:** neues tournament_live_screen.dart (TabBar), Wiederverwendung von
  tournament_match_list_screen / tournament_standings_screen / tournament_match_detail_screen,
  tournament_routes.dart. Leerzustand „kein aktuelles Match“.
- **Verifikation:** Widget-Test Default-Tab + Tab-Inhalte + „Turnier-Infos“-Navigation.

## Block M1 — Echte Team-/Spielernamen statt „A/B“

- Überall, wo heute „A/B“ die Begegnung repräsentiert (Match-Liste, Satz-Eingabe, Match-Detail,
  öffentliche Screens), die **exakte Teambezeichnung** zeigen; bei Einzelturnieren Spielername = Teamname.
- Match-Listen-Einträge (Z. 144): duellierende Namen klar sichtbar je Eintrag.
- Satz-Eingabe (Z. 149): Spalten/Labels tragen die echten Namen, nicht „A“/„B“.
- **Dateien:** tournament_match_list_screen.dart, tournament_set_input.dart, match_detail_screen.dart,
  public/* Screens; ggf. Name-Resolver (participant → display name) wiederverwenden/zentralisieren.
- **Verifikation:** Widget-Tests prüfen echte Namen statt „A/B“ in Liste/Eingabe/Detail.

## Block P1 — Öffentliche Match-Details + teilbarer Link

- Öffentliche Ansicht: Match-Details auch für LAUFENDE Matches einsehbar; **pro Match teilbarer Link**
  (Route /public/match/:matchId existiert — prüfen/erweitern), read-only.
- Server/RLS: öffentlicher Read des Match-Details für live/finalized Turniere (ADR-0023 spectator-RLS),
  ohne PII. Live-Updates über bestehenden anon-Broadcast (kein neues Polling, ADR-0029).
- **Dateien:** public/public_match_screen.dart (+ ggf. Detail-Inhalt), public routes, ggf. RLS-Migration.
- **Verifikation:** öffentlicher Match-Link rendert laufendes Match read-only; RLS-Probe (kein PII,
  nur live/finalized).

## Block N1 — Notifications: Turnier-Ende + Rundendauer

- Neue Inbox-kind **tournament_finished** (Turnier beendet) an alle Teilnehmer.
- Jede Turnier-Meldung (started/round/finished) nennt die **konfigurierte Rundenzeit** der jeweiligen
  Runde („Runde X — Spielzeit N min“).
- **Dateien:** Server (Inbox-Trigger/RPC der Turnier-Notifications + kind-CHECK erweitern, additive
  Migration), inbox kinds (Client-Enum/Mapping/Rendering).
- **Verifikation:** Server-Proben (finished-Meldung + Dauer im Payload); Client rendert die neue kind;
  kind-CHECK-Migration additiv.

## Block O1 — Live-Dashboard entfernen

- tournament_live_dashboard_screen.dart + tournament_live_dashboard_provider.dart + Route + den
  Einstiegs-Button im Detail entfernen. **Sicherstellen**, dass Override/Forfeit/Pitch-Zuweisung
  weiterhin über das Match-Detail erreichbar sind (keine Funktion verlieren).
- **Dateien:** o.g. löschen, tournament_detail_screen.dart (Button), tournament_routes.dart, Tests anpassen.
- **Verifikation:** grep: keine Referenz mehr auf das Dashboard; Override/Forfeit/Pitch weiter erreichbar;
  Suite grün.

---

## Empfohlene Reihenfolge
M2 (Bugfix, höchster Nutzen) → H1 → H3 → H2 → M1 → P1 → N1 → O1.
(H1+H3 hängen zusammen — Live-Kachel führt in die 3-Reiter-Ansicht.)

## Guardrails (jeder Block)
- **Solo-Training TABU** (CLAUDE.md) — nicht anfassen.
- DB nur additive Migration via `supabase migration up`, NIE `db reset`; Timestamp nach jüngster;
  CREATE OR REPLACE auf aktueller Definition (Stale-Body per Diff ausschließen).
- Kein neues `Timer.periodic` für Server-State (ADR-0029); Tokens nur über KubbTokens; UI-Strings
  Deutsch, Code-Kommentare Englisch.
- Pro Block selbst verifizieren (analyze ohne neue Issues, Suite grün), ein Commit/Block; Push nur auf Ansage.

## Offene Mini-Punkte (vor/while Umsetzung)
- M2-Regel: GEKLÄRT (wertungsmodus-abhängig — EKC=Kubbs, Schoch/Classic=König-gefallen-sonst-none,
  siehe Block M2). Nur EKC-Detail (pro-Satz-Sieger vs Match-kumuliert) noch final zu bestätigen.
- P1: GEKLÄRT — Live-Updates über bestehenden anon-Broadcast.
