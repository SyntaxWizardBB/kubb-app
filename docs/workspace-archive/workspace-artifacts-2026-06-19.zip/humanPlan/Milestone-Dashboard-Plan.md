# Milestone — Veranstalter-Dashboard & Zeitgesteuerter Turnier-Ablauf

**Status:** Plan-Entwurf v2 (zum Review). Quelle: ProjectPlan.txt (BUG3 „Veranstalter-Dashboard"),
Gespräch 2026-06-09.
**Ziel:** Der Veranstalter **überwacht** ein (oder mehrere parallele) Turnier(e), die **automatisch
nach einem Zeitplan ablaufen** — Runden, Pausen, Uhren laufen selbsttätig synchron auf allen Geräten;
der Veranstalter greift nur bei **Fehlern/Eskalationen** ein und kann **Start/Pause/Skip** steuern.

---

## Geklärte Entscheide (User) — verbindlich

1. **Mehrere Turniere gleichzeitig:** Ein Veranstalter managt oft parallele Turniere (z.B. Liga C +
   Liga A/B). Das Dashboard zeigt **alle** seine Turniere in einem **Overview**, je mit
   **Start/Pause/Skip**-Steuerung (vor/zurück im Zeitplan).
2. **Zeitplan ergibt sich aus der Config:** Match-Zeit + Pausen-Zeit pro Phase (Vorrunde/Final).
   Beispiel Gruppenphase: Begegnung 30min, Pause 5min → Match läuft 30min, danach 5min Pause, dann
   startet die nächste Begegnung automatisch. Schoch: Runde 1 startet bei Turnierstart (30min); nach
   30min UND wenn **alle** Resultate eingetragen sind, werden die nächsten Begegnungen (Ranking +
   Buchholz) berechnet/gelistet; nach 5min Pause startet die nächste Runde.
3. **Ablauf primär automatisch, Veranstalter kontrolliert nur:** Resultate sind immer eingetragen,
   der Veranstalter überwacht und greift bei Fehlern/Eskalationen ein.
4. **Aufruf-Frist + Notify bei jedem Timer-Event:** Erst nach **Publikation der neuen Runde** startet
   der Timer (Aufruf-/Pausen-Frist davor). **Jedes Timer-Event löst eine Mitteilung/Notify aus.**
5. **Tiebreak hält den Timer:** Läuft die Match-Zeit ab ohne Ergebnis, **hält** der Timer an, bis das
   Resultat eingetragen ist — erst dann läuft der Ablauf weiter (kein globaler Tiebreak-Schalter nötig).
6. **Zugang = Turnier-Admin:** Alle Vereins-Rollen **Creator** und **Referee** dürfen das Dashboard
   nutzen (auch Owner/Admin). **Referee** = Turnier-Admin (Punkte eintragen, Zeit managen, Pause/Skip)
   — aber **kein Setup**. → koppelt an den Berechtigungskonzept-Milestone.

---

## Kern-Konzept: Zeitgesteuerter Ablaufplan (Schedule / Runner)

### Config → Zeitplan
Pro Phase aus der bestehenden Config ableiten:
- **Match-Dauer:** Vorrunde `round_time_seconds` (Default 1800); KO/Final aus `ko_round_formats[]`
  (ggf. um Zeit/Pause-Feld ergänzen — siehe offene Punkte).
- **Pausen-/Aufruf-Dauer:** `break_between_matches_seconds`.
- **Tiebreak-Trigger:** `prelimTiebreakAfterSeconds` (nur Anzeige; Tiebreak hält ohnehin, Punkt 5).

### Zeitstempel pro Runde (Server-autoritativ)
Neue Tabelle `tournament_round_schedule` (oder Felder je Stage/Runde):
`published_at` · `starts_at` (= published_at + Aufruf-/Pausen-Frist) · `ends_at` (= starts_at +
Match-Dauer) · `status` (`published` → `call` → `running` → `awaiting_results` → `completed`).
Die Uhr jedes Matches ankert auf `starts_at`/`ends_at` der Runde (skew-korrigiert).

### Zustandsautomat pro Runde
```
[Runde N berechnet] → published (Notify: "Runde N, Pitch X, Start HH:MM")
   → call/Pause-Fenster (break_seconds, Countdown auf allen Geräten)
   → running (starts_at erreicht; Notify "Match läuft"; Uhr zählt bis ends_at)
   → ends_at erreicht:
        alle Resultate da? → completed → Runde N+1 berechnen (Trigger) → published …
        nicht alle / Tiebreak? → awaiting_results (Uhr HÄLT, Dashboard flaggt; Veranstalter/
            Spieler tragen ein) → sobald komplett → completed → weiter
[letzte Runde completed] → tournament finalize
```
- **Vorwärts-Treiber:** Nächste Runde wird **bei Resultat-Vollständigkeit per Trigger** materialisiert
  (Stage-Runner `tournament_run_stage_graph` / `advance_ko_winner` existieren bereits). Der **Zeit-
  Teil** (Pause, Match-Fenster) ist in den Zeitstempeln kodiert → Clients rendern Countdowns, kein
  Server-Tick nötig, damit die Uhr „läuft".
- **Tiebreak/Hold:** Eine Runde wird erst `completed`, wenn alle Matches terminal sind → fehlt eins
  (Tiebreak), hält der Ablauf automatisch; das Match-Clock friert (Pause-Semantik), bis eingetragen.

### Skip / Start / Pause (Veranstalter)
- **Skip vor:** `starts_at := now()` (Aufruf-/Pausen-Frist überspringen) bzw. Runde sofort
  abschließen/weiterspringen.
- **Skip zurück:** zum vorigen Zeitpunkt (Frist verlängern / Runde erneut „aufrufen").
- **Pause/Resume:** friert die Zeitstempel (akkumulierte Pausenzeit) → alle Uhren stehen, Resume rechnet
  weiter.
- **Start:** Turnierstart bootet Runde 1 (publish → call → running).

---

## Architektur-Entscheid: Wie „automatisch" ohne offenes Gerät?

| Mechanismus | braucht | deckt ab | Infra heute |
|---|---|---|---|
| **Zeitstempel + Client-Countdown** (skew-korr.) | nichts Neues | Uhren, Pausen-/Match-Fenster, „Start nach Pause" | ✅ vorhanden |
| **Result-Trigger** (nächste Runde materialisieren) | nichts Neues | Runden-Fortschritt bei Vollständigkeit | ✅ vorhanden (Stage-Runner) |
| **Durable Inbox-Notify bei Publish** („Runde N, Start HH:MM") | nichts Neues | Spieler-Information | ✅ vorhanden (`_tournament_notify_participants`) |
| **Exakt getaktete Notify/Force-Advance** („Match startet JETZT", Auto-Vorrücken obwohl Ergebnis fehlt) | **Server-Tick** (pg_cron) | reine Zeit-Events ohne DB-Auslöser | ❌ kein pg_cron/Edge |
| **Out-of-App Push** zur Match-Zeit | **Push-Infra** | echte Handy-Pushes | ❌ Seam, P8 deferred |

**Entschieden (User, gelockt):** Voller autonomer Ablauf via **pg_cron-Tick** (Phase E, jetzt im Scope) —
läuft auch ohne offenes Veranstalter-Gerät: Zeitstempel + Trigger tragen die Uhren/den Fortschritt,
der 1-Min-Tick feuert die reinen Zeit-Übergänge (`call`→`running`, `ends_at`+vollständig→nächste Runde)
und die exakt getakteten Notifies. **pg_cron 1.6 ist in der lokalen DB verfügbar** (nur `create extension`
nötig); **pg_net 0.14 ist installiert** (später für HTTP-Push nutzbar). **Echte Out-of-App-Pushes** bleiben
dennoch am Push-Milestone (LastMilestonePublishApp) hängen — bis dahin Inbox + lokale Notifications.

---

## Datenmodell (additiv, kein db reset)

- **NEU** `public.tournament_round_schedule(tournament_id, stage_node_id|round_number, published_at,
  starts_at, ends_at, break_seconds, match_seconds, status, paused_at, paused_accum_seconds)` — CDC-Tabelle
  (in `supabase_realtime`, RLS auf `tournament_id`).
- **`tournament_matches`** (bereits CDC): `started_at` ab Spielbereitschaft/Runden-Start anker;
  optional `paused_at`, `paused_accum_seconds` falls Match-genaue Pause nötig.
- **`tournaments`**: `paused_at` (Turnier-weite Pause).
- Restzeit-Formel identisch Server/Client (siehe Schedule-Block).

---

## Phasen

### Phase A — Schedule-Engine + Sync-Uhr  *(Fundament)*
- **A1 Schedule-Datenmodell + Ableitung aus Config** (`tournament_round_schedule`; Publish/Start/Ends
  beim Materialisieren einer Runde setzen — in `tournament_start`, `tournament_pair_round`,
  `tournament_start_ko_phase`, `tournament_generate_stage_matches`).
- **A2 Auto-Anker `started_at`** bei Spielbereitschaft (Trigger), gekoppelt an `starts_at` der Runde
  (nach Aufruf-/Pausen-Frist).
- **A3 Server-Zeit/Skew:** RPC `app_server_now()`, Client `serverClockOffsetProvider`, `MatchTimer`
  rechnet mit Offset. Pause-/Hold-Felder in der Restzeit-Formel.
- **A4 Client-Rendering:** Pausen-Countdown („nächste Runde in mm:ss"), Match-Countdown, Hold-Anzeige
  bei `awaiting_results`/Tiebreak.

### Phase B — Veranstalter-Dashboard *(Cockpit, Multi-Turnier)*
- **B1 Overview aller eigenen Turniere** (Creator/Referee/Owner/Admin; status published/live): je Karte
  Phase, aktuelle Runde, Schedule-Status, Restzeit, offene/strittige Matches.
- **B2 Detail je Turnier:** Runden-/Match-Liste mit Status/Pitch/Uhr; **Start/Pause/Resume/Skip
  (vor/zurück)**.
- **B3 Eingriffs-Aktionen** (bestehende RPCs konsolidiert): Ergebnis eintragen (Override, T1), Forfait,
  Pairing-Override; manuelle Phasen-Schritte wo nötig (`pair_round`, `start_ko_phase`).
- **B4 Route** `/tournament/dashboard` (Overview) + `/tournament/:id/dashboard` (Detail); Zugang =
  Turnier-Admin (siehe Permissions). UI strikt nach `docs/design/`.

### Phase C — Notifications bei Schedule-Events
- Publish-Notify mit Startzeit + Pitch (durable Inbox, vorhanden). Optional pg_cron-Tick für „Match
  startet jetzt"/„Pause vorbei"/„Zeit fast um". **Jedes Timer-Event = ein Event** (Punkt 4) — über
  Inbox + (später) Push.

### Phase D — Vor-Ort-Check-in + Eingriffs-Tools
- **Check-in** (BUG3): Anwesenheit markieren (`tournament_participants.checked_in_at`), No-Show →
  Forfait-Shortcut, Eskalations-Sicht (strittige/überfällige Matches) im Dashboard.

### Phase E — pg_cron-Autonomie-Tick *(im Scope, gelockt)*
- `create extension pg_cron`; 1-Min-Job `tournament_schedule_tick()`: Runden, deren `ends_at` vorbei +
  alle Resultate da → `completed` anstoßen; `call`-Fenster vorbei → `running`; Zeit-Notifies emittieren.
  Macht den Ablauf voll geräteunabhängig. Idempotent (gleicher Tick darf doppelt laufen ohne Schaden).
- Reihenfolge: kann früh nach A kommen (A liefert die Zeitstempel-Wahrheit, E den Treiber).

---

## Permissions / Zugang (Turnier-Admin)

- **Entschieden (User, gelockt): Minimal-Gate jetzt.** Gate `canAdministerTournament(tournament, user)`
  = Creator **ODER** Vereins-Rolle in {owner, admin, referee} des besitzenden Clubs — direkt geprüft
  (Server-RPC + Client-Provider).
- **Referee:** Dashboard + alle Laufzeit-Aktionen (Punkte, Zeit, Pause/Skip), **kein** Setup/Edit-Config.
- Das saubere Rollenmodell (Berechtigungskonzept-Milestone, Rollen-Konsolidierung) wird **nachgezogen**;
  das Gate wird dann an einer Stelle ausgetauscht.

---

## Realtime / Messaging (ADR-0029-konform)

- Alle Live-Zustände (Schedule-Zeitstempel, Pause, `started_at`, Status) auf CDC-Tabellen →
  **automatischer Push, kein neues Polling**.
- `app_server_now()` = seltener Offset-Sync, kein Sekunden-Poll.
- Notifies über die Inbox-Spine; echte Out-of-App-Pushes am Push-Milestone.

## RPC-/Trigger-Übersicht

| Neu/Ändern | Objekt | Phase |
|---|---|---|
| NEU Tabelle | `tournament_round_schedule` (CDC) | A1 |
| ÄNDERN | Materialisierungs-RPCs setzen Schedule-Zeitstempel | A1 |
| NEU Trigger | `tournament_match_autostart` (started_at an `starts_at`) | A2 |
| NEU RPC | `app_server_now()` | A3 |
| NEU RPC | `tournament_pause`/`resume`/`skip_forward`/`skip_back` (Turnier-Admin) | B2 |
| WIEDERVERWENDEN | override / forfeit / pairing-override / pair_round / start_ko_phase | B3 |
| NEU Spalte+RPC | `tournament_participants.checked_in_at` + checkin | D |
| NEU Job *(opt.)* | pg_cron 1-Min-Tick | E |

## Entscheidungen (Stand 2026-06-09)

- **E1 — Autonomie-Infra: GELOCKT → pg_cron-Tick im Scope** (Phase E). pg_cron 1.6 lokal verfügbar.
- **E2 — Final-/KO-Zeiten: GEKLÄRT → keine neuen Felder.** `MatchFormatSpec` (= Einträge in
  `ko_round_formats[]`) trägt bereits `timeLimitSeconds` **und** `breakBetweenMatchesSeconds` (+
  `tiebreakAfterSeconds`, `finalNoTiebreak`); die Vorrunde `round_time_seconds` +
  `break_between_matches_seconds`. Der Scheduler liest Match-/Pausen-Dauer pro Phase/Runde direkt daraus.
- **E3 — Pause-Granularität: Default Turnier-weit** (`tournaments.paused_at`, friert alle laufenden
  Uhren) + Einzel-Match als Sonderfall (Match-Felder). *(bei Bedarf bestätigen)*
- **E4 — Permissions-Kopplung: GELOCKT → Minimal-Gate jetzt** (Creator + Club {owner,admin,referee}),
  Berechtigungskonzept zieht nach.

## Guardrails
Additive Migrationen (nie `db reset`; Bestandsdaten nicht brechen); `CREATE OR REPLACE` nur auf aktueller
Definition; kein neues Polling; DE-Komm./EN-Code; Design-System verbindlich; blockweise verifizieren
(analyze + Tests) + ein Commit/Block; Push nur auf Ansage; Solo-Training unangetastet.

## Bezug zu ProjectPlan.txt
Subsumiert: BUG3 „Veranstalter-Dashboard / Vor-Ort-Checkin", Uhr-/Realtime-Anforderung, Pausen-/Ablauf-
Management. Abgegrenzt: `AdminDashBoard` (app-weiter Support, User-Rechte) bleibt eigener Milestone;
echte Push-Provider am LastMilestonePublishApp.
