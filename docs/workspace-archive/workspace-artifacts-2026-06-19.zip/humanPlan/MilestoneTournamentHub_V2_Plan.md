# Tournament Milestone — V2-Plan (Format-/Regelwerk-Überarbeitung)

**Status:** Plan — Entwurf, läuft NACH V1. Mehrere Punkte brauchen vor Umsetzung eine Entscheidung
(unten markiert). Quelle: humanPlan/MilestoneTourierHUB.txt (Teil B „GEWÜNSCHT“) + prompts.txt.
**Abgrenzung zu V1:** V1 = Anzeige/UX + Score-Bugfix. V2 = ändert, WAS konfigurierbar ist und WIE
das Turnier läuft → tief in **Setup-Wizard + Datenmodell (Migrationen) + Domain-Engine
(kubb_domain Pairing/Bracket) + Server-RPCs**. Höheres Risiko, längere Laufzeit.
**Arbeitsweise:** blockweise über die 4-Rollen-Pipeline; Split **Domain → Server → UI**.

## Gewünschte Änderungen (aus der Milestone-Datei)
1. **Formate reduzieren** auf **Gruppenphase + Schoch** (jeweils optional mit KO); round_robin/swiss-
   „Zeugs“ raus. (B3.1, Z. 223-224)
2. **KO single-out / double-out** wählbar (`bracket_type`). (Z. 258-259)
3. **Tiebreak ODER Mighty Finisher** als Entweder-oder (`ko_tiebreak_method`). (Z. 261-263)
4. **Sätze zum Sieg pro Vorrunde UND pro KO-Runde** frei wählbar (per-round). (Z. 247-248)
5. **Matchzeit + Pausen** konfigurierbar (time_limit, break_between_matches). (Z. 247-248)
6. **Organisator/Admin: Details auch NACH Veröffentlichung editieren UND starten.** (Z. 198-202)

---

## Block V2-A — Domain + Datenmodell (zuerst)

- kubb_domain Config-Typen anpassen: Format-Auswahl auf Gruppenphase/Schoch (+ optional KO);
  `bracket_type` single/double-out; `ko_tiebreak_method` als Entweder-oder; per-Runde-Match-Format
  (`ko_round_formats[]` + Vorrunden-Sätze); Matchzeit/Pausen-Felder.
- Validierung im Domain (reine Dart-Regeln) + Tests.
- **GEKLÄRT (User):** NUR die im UI gezeigten (neuen) Formate müssen funktionieren — **alte Formate
  braucht es NICHT** (kein Alt-Format-Support / keine Rückwärts-Kompatibilität als Option).
  → Ziel-Format-Set = das im neuen Wizard angebotene Set (Gruppenphase/Schoch ± KO); round_robin/swiss
  als Auswahl entfernen.
- **Migration:** CHECK-Constraints/Spalten auf das neue Set. Da alte Formate nicht gebraucht werden,
  bestehende Alt-Format-Zeilen (falls vorhanden) bereinigen/auf das neue Set mappen statt erhalten
  (vor Umsetzung lokal prüfen, ob überhaupt Alt-Format-Daten existieren). Additiv, kein db reset.
- **NOCH ZU PRÄZISIEREN (V2-Start):** das exakte Label/Set im Wizard (z.B. {Gruppenphase,
  Gruppenphase→KO, Schoch, Schoch→KO}); „Gruppenphase“ == heutige round_robin-Mechanik?

## Block V2-B — Engine (Pairing / Bracket / Match-Auflösung)

- Pairing/Bracket-Engine an das reduzierte Format-Set anpassen; Double-Elim existiert bereits
  (ADR-0027/0028) — single/double-out sauber wählbar verdrahten.
- Per-Runde-Sätze honorieren. **Tiebreak↔Mighty-Finisher (GEKLÄRT): gilt fürs GANZE KO (global,
  EINE Einstellung), nicht pro Runde.**
- **Live-Neuberechnung (GEKLÄRT, zentrales V2-Feature):** wenn der Organisator nach dem Start etwas
  ändert, werden abhängige Ergebnisse NEU AUSGERECHNET (Pairings/Bracket/Standings). Engine muss
  idempotent neu rechnen können und bereits gespielte/finalisierte Matches korrekt berücksichtigen
  (nicht zerstören) — das ist der größte Risiko-/Aufwandsblock.
- Tests: Pairing je Format, KO single vs double, per-Runde-Sätze, globaler Finisher, Neuberechnung
  nach Änderung (inkl. „bereits gespielte Matches bleiben konsistent“).

## Block V2-C — Server-RPCs

- tournament_create/update-Validierung auf das neue Config-Schema; Start-Phasen-Logik anpassen.
- **Edit-nach-Veröffentlichung (GEKLÄRT, User):** **ALLES bleibt editierbar** (auch nach
  Veröffentlichung/live) und wird bei Änderungen **neu ausgerechnet** (siehe V2-B Live-Neuberechnung).
  updateTournament entsprechend erweitern; Start-Recht bleibt; Organisator/Admin. Additive Migration,
  CREATE OR REPLACE auf aktueller Definition (Stale-Body-Diff).
- **Wichtig (Konsistenz-Guard):** „alles editierbar + neu rechnen“ darf bereits FINALISIERTE Matches/
  bereits gespielte Ergebnisse nicht verfälschen — die Neuberechnung muss diese als fix behandeln und
  nur Abhängiges (zukünftige Pairings, Standings) aktualisieren. Genaues Verhalten bei Konflikten
  (z.B. Format-Wechsel mitten im laufenden Bracket) am V2-Start festklopfen.

## Block V2-D — Setup-Wizard / UI

- Wizard auf das neue Optionsset umbauen: Format (Gruppenphase/Schoch ± KO), KO single/double-out,
  Tiebreak-oder-Mighty-Finisher-Toggle, Per-Runde-Satz-Konfiguration, Matchzeit/Pausen.
- Edit-nach-Publish-UI (Organisator/Admin) gemäß V2-C-Guards.
- Konsistenz mit V1-Stammdaten-Widget (zeigt die neuen Felder automatisch).
- Tests: Wizard-Flows je Format; Edit-nach-Publish.

## Block V2-E — Tests + Migration-Sicherheit + Rollout

- Bestandsdaten-Migrationstest (alte Turniere bleiben lesbar/lauffähig).
- Volle Suite grün; analyze sauber; pgTAP/psql für die RPC-/Constraint-Änderungen.

---

## Reihenfolge
V2-A (Domain+Migration) → V2-B (Engine) → V2-C (RPCs) → V2-D (Wizard/UI) → V2-E (Härtung).

## Guardrails
Wie V1: Solo-Training TABU; additive Migrationen (nie db reset; Bestandsdaten nicht brechen);
CREATE OR REPLACE auf aktueller Definition; kein neues Polling; Konventionen DE/EN; Block-weise
verifizieren + ein Commit/Block; Push nur auf Ansage.

## Geklärt (User) — FINAL
- **Format-Set: GENAU 2 Formate, beide mit PFLICHT-KO** — `Gruppenphase→KO` und `Schoch→KO`.
  Es gibt KEIN Turnier ohne KO. swiss + reine Nicht-KO-Varianten (round_robin allein, schoch allein,
  single_elimination allein) entfallen aus dem Wizard. „Gruppenphase" = round_robin-Mechanik (Gruppen,
  Jeder-gegen-jeden). KO ist also immer vorhanden -> bracket_type (single/double-out), Finisher (global)
  und KO-Runden-Sätze gelten immer.
- **Live-Neuberechnung:** alles editierbar; bei Änderung werden NUR noch nicht gespielte Paarungen/
  Bracket/Standings neu berechnet; FINALISIERTE Matches bleiben unverändert; eine engine-inkompatible
  Änderung (z.B. Format-Wechsel nachdem das KO schon läuft) wird mit klarer Meldung ABGELEHNT statt das
  Turnier zu zerschießen.
- Tiebreak↔Mighty-Finisher gilt fürs GANZE KO (global).
- **Bestandsdaten:** alte Format-Werte werden NICHT gebraucht, aber bestehende DB-Zeilen dürfen NICHT
  brechen — CHECK bleibt für Altwerte tolerant (oder Mapping), die Einschränkung auf die 2 Formate
  greift am Wizard/create-Pfad.

## Geklärt (User) — alt
- Nur die im UI gezeigten/neuen Formate; alte braucht es nicht (V2-A).
- Alles editierbar + Neuberechnung bei Änderungen (V2-B/V2-C); finalisierte Matches bleiben fix.
- Tiebreak↔Mighty-Finisher gilt fürs GANZE KO (global).

## Vor V2-Start noch zu präzisieren
1. Exaktes Wizard-Label/Set der Formate (z.B. {Gruppenphase, Gruppenphase→KO, Schoch, Schoch→KO});
   „Gruppenphase“ == heutige round_robin-Mechanik?
2. Konfliktverhalten der Live-Neuberechnung bei harten Änderungen (z.B. Format-Wechsel, während ein
   Bracket schon läuft / Matches finalisiert sind).
